# visualize_attention.py
import numpy as np
import torch
import matplotlib.pyplot as plt
import seaborn as sns  # ✅ 修正导入


def visualize_cross_attention(model, x_enc, save_path=None):
    """
    可视化双向融合中的 Cross-Attention 权重（Inception → TimesNet）。

    Args:
        model: 训练好的 FusedModel / TimeCasper 实例
        x_enc: 输入张量，shape (1, T, C)
        save_path: 保存路径（如 'viz/cross_attn.png'），若为 None 则显示图像
    """
    model.eval()
    with torch.no_grad():
        enc_out = model.enc_embedding(x_enc, None)

        # TimesNet 分支
        times_out = enc_out
        for block in model.times_blocks:
            times_out = model.layer_norm(block(times_out))

        # Inception 分支
        temp_out = model.temp_backbone(enc_out)

        # 提取 Cross-Attention 的 Q 和 K（假设使用 cross_attn_1to2）
        fusion_layer = model.bidirectional_fusion
        q_proj = fusion_layer.cross_attn_1to2.q_proj
        k_proj = fusion_layer.cross_attn_1to2.k_proj
        n_heads = fusion_layer.cross_attn_1to2.n_heads

        q = q_proj(temp_out)  # (B, T, C)
        k = k_proj(times_out)  # (B, T, C)

        B, T, C = q.shape
        D = C // n_heads

        q = q.view(B, T, n_heads, D).transpose(1, 2)  # (B, H, T, D)
        k = k.view(B, T, n_heads, D).transpose(1, 2)  # (B, H, T, D)

        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / (D ** 0.5)  # (B, H, T, T)
        attn_probs = torch.softmax(attn_scores, dim=-1)
        # print("Top 5 max attention weights:")
        # attn_flat = attn_probs[0, 0].cpu().numpy().flatten()
        # top5 = np.argsort(-attn_flat)[:30]
        # for idx in top5:
        #     i, j = divmod(idx, T)
        #     print(f"  Query t={i} → Key t={j}, weight={attn_flat[idx]:.3f}")
        # # 可视化第一个样本的第一个头
        attn_map = attn_probs[0, 0].cpu().numpy()  # (T, T)

    plt.figure(figsize=(8, 6))
    sns.heatmap(attn_map, cmap='viridis', cbar=True)
    plt.title('Cross-Attention: InceptionTime (Query) → TimesNet (Key)')
    plt.xlabel('TimesNet Time Steps (Key)')
    plt.ylabel('InceptionTime Time Steps (Query)')
    plt.tight_layout()

    if save_path is not None:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"✅ Cross-attention plot saved to: {save_path}")
    else:
        plt.show()

    plt.close()  # 防止内存泄漏