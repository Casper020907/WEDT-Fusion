# # visualize_periods.py （新增或替换原函数）
# 
# import torch
# import matplotlib.pyplot as plt
# import numpy as np
# import seaborn as sns
# 
# try:
#     plt.style.use(['science', 'no-latex'])  # SCI 期刊风格
# except:
#     pass  # 无 scienceplots 时回退默认
# 
# from models.TimeCasper import SWT_for_Period, WaveletEmbedding
# 
# 
# def plot_swt_heatmap(x_sample, wavelet='db4', save_path=None, channel_idx=0):
#     """
#     可视化 SWT 小波系数热力图（时间 vs 尺度）
#     用于判断：小波是否学到结构化特征（如周期、突变），而非噪声
# 
#     Args:
#         x_sample: (1, T, C)
#         wavelet: 小波基
#         save_path: 保存路径
#         channel_idx: 通道索引
#     """
#     device = x_sample.device
#     B, T, C = x_sample.shape
#     assert B == 1
# 
#     # 提取 SWT
#     swt_layer = WaveletEmbedding(
#         d_channel=C,
#         swt=True,
#         requires_grad=False,
#         wv=wavelet,
#         m=int(np.log2(T)) - 2
#     ).to(device)
# 
#     x_in = x_sample.permute(0, 2, 1)  # (B, C, T)
#     coeffs = swt_layer(x_in)  # (B, C, level+1, T)
#     detail_coeffs = coeffs[0, channel_idx, 1:, :].cpu().numpy()  # (L, T)
# 
#     L, _ = detail_coeffs.shape
#     scales = [2 ** (L - i) for i in range(L)]  # coarse → fine
# 
#     # ===== 热力图 =====
#     fig, ax = plt.subplots(1, 1, figsize=(10, 4))
#     im = ax.imshow(
#         detail_coeffs,
#         aspect='auto',
#         cmap='RdBu_r',  # 对称色谱，零为中心
#         interpolation='nearest'
#     )
# 
#     ax.set_yticks(range(L))
#     ax.set_yticklabels([f'Scale {s}' for s in scales])
#     ax.set_xlabel('Time Step', fontsize=12)
#     ax.set_ylabel('SWT Scale (Coarse → Fine)', fontsize=12)
#     ax.set_title(f'SWT Coefficients Heatmap ({wavelet}, Channel {channel_idx})', fontsize=13)
# 
#     # 添加 colorbar
#     cbar = plt.colorbar(im, ax=ax, pad=0.02)
#     cbar.set_label('Coefficient Value', rotation=90, labelpad=15)
# 
#     plt.tight_layout()
# 
#     if save_path:
#         plt.savefig(save_path, dpi=400, bbox_inches='tight')
#         print(f"✅ SWT heatmap saved to: {save_path}")
#     else:
#         plt.show()
# 
#     plt.close()
# 
#     # ===== 分析建议 =====
#     print("\n🔍 How to interpret the heatmap:")
#     print("- **Structured patterns** (e.g., vertical stripes, diagonal lines) → meaningful periodicity")
#     print("- **Random noise** (speckled, no clear pattern) → ineffective SWT or unsuitable data")
#     print("- **Large coefficients at coarse scales** → long-term trends captured")
#     print("- **Sharp spikes at fine scales** → abrupt changes / anomalies detected")
# 
# 
# import torch
# import matplotlib.pyplot as plt
# import numpy as np
# import seaborn as sns
# 
# # 强制使用明亮风格（即使有 scienceplots 也避免暗色）
# plt.rcParams.update({
#     "figure.facecolor": "white",
#     "axes.facecolor": "white",
#     "font.size": 12,
#     "axes.edgecolor": "black",
#     "axes.linewidth": 0.8,
# })
# 
# 
# def plot_swt_periods_sci(x_sample, wavelet='db4', k=3, save_path=None, channel_idx=0):
#     """
#     明亮、清新、SCI 一区风格的 SWT 能量分布图（非暗色）
# 
#     Args:
#         x_sample: (1, T, C)
#         wavelet: 小波基
#         k: top-k 周期数
#         save_path: 保存路径（如 'figs/swt_energy.png'）
#         channel_idx: 可视化通道索引（默认 0）
#     """
#     device = x_sample.device
#     B, T, C = x_sample.shape
#     assert B == 1, "Only support single sample"
# 
#     # 获取选中的周期
#     period_list, period_weight = SWT_for_Period(x_sample, k=k, wavelet=wavelet)
# 
#     # 提取 SWT 系数
#     swt_layer = WaveletEmbedding(
#         d_channel=C,
#         swt=True,
#         requires_grad=False,
#         wv=wavelet,
#         m=int(np.log2(T)) - 2
#     ).to(device)
# 
#     x_in = x_sample.permute(0, 2, 1)  # (B, C, T)
#     coeffs = swt_layer(x_in)  # (B, C, level+1, T)
#     detail_coeffs = coeffs[:, :, 1:, :]  # 去掉近似系数 (B, C, L, T)
#     L = detail_coeffs.shape[2]
# 
#     # 计算能量
#     if channel_idx is not None:
#         energies = torch.sum(detail_coeffs[0, channel_idx] ** 2, dim=-1)  # (L,)
#     else:
#         energies = torch.mean(torch.sum(detail_coeffs ** 2, dim=-1), dim=1).squeeze()  # (L,)
# 
#     energies = energies.cpu().numpy()
#     scales = [2 ** (L - i) for i in range(L)]  # coarse → fine
# 
#     # ===== 绘图：明亮清新风格 =====
#     fig, ax = plt.subplots(1, 1, figsize=(7, 4.5))
# 
#     # 使用 light pastel 色系：柔和、不刺眼、不暗
#     colors = sns.color_palette("pastel", L)  # 或用 "light:#66c2a5" 自定义
# 
#     bars = ax.bar(
#         range(1, L + 1),
#         energies,
#         color=colors,
#         edgecolor='gray',
#         linewidth=0.6,
#         alpha=0.9
#     )
# 
#     # 标记选中的周期（用醒目的 coral 红，非深红）
#     marked = set()
#     for i, p in enumerate(period_list):
#         if p in scales:
#             idx = scales.index(p)
#             if p not in marked:
#                 ax.axvline(
#                     x=idx + 1,
#                     color='#E74C3C',  # Bright coral red (not dark!)
#                     linestyle='--',
#                     linewidth=2.0,
#                     label=f'Top-{i + 1} Period = {p}'
#                 )
#                 marked.add(p)
# 
#     # 标签与标题（加粗但不过重）
#     ax.set_xlabel('SWT Scale (Coarse → Fine)', fontsize=13)
#     ax.set_ylabel('Energy (L2 Norm)', fontsize=13)
#     ax.set_title(f'SWT Energy Distribution ({wavelet})', fontsize=14, fontweight='semibold')
# 
#     # X 轴刻度：旋转 + 对齐
#     ax.set_xticks(range(1, L + 1))
#     ax.set_xticklabels([f'{s}' for s in scales], rotation=45, ha='right', fontsize=11)
# 
#     # 图例美化
#     if marked:
#         ax.legend(
#             loc='upper right',
#             frameon=True,
#             fancybox=True,
#             shadow=False,
#             framealpha=0.95,
#             edgecolor='lightgray',
#             fontsize=11
#         )
# 
#     # 网格：浅灰色，细线
#     ax.grid(True, linestyle='-', linewidth=0.5, alpha=0.4, color='#cccccc')
#     ax.set_axisbelow(True)  # 网格在柱子下方
# 
#     plt.tight_layout()
# 
#     # 保存或显示
#     if save_path:
#         plt.savefig(save_path, dpi=600, bbox_inches='tight', transparent=False)
#         print(f"✅ SWT energy plot (bright style) saved to: {save_path}")
#     else:
#         plt.show()
# 
#     plt.close()
# utils/visualize_periods.py

import torch
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import os

try:
    plt.style.use(['science', 'no-latex'])  # SCI 期刊风格
except:
    pass  # 无 scienceplots 时回退默认

from models.TimeCasper import SWT_for_Period, WaveletEmbedding


# 设置全局字体和样式，确保中文显示正常（如果需要）
# plt.rcParams['font.sans-serif'] = ['SimHei'] # 用来正常显示中文标签
# plt.rcParams['axes.unicode_minus'] = False # 用来正常显示负号

def plot_swt_heatmap(x_sample, wavelet='db4', save_path=None, channel_idx='all'):
    """
    可视化 SWT 小波系数热力图（时间 vs 尺度）
    用于判断：小波是否学到结构化特征（如周期、突变），而非噪声

    Args:
        x_sample: (1, T, C) Tensor
        wavelet: 小波基字符串
        save_path: 保存路径
        channel_idx: 通道索引 (int) 或 'all' (绘制所有通道)
    """
    device = x_sample.device
    B, T, C = x_sample.shape
    assert B == 1, "Only support single sample visualization"

    # 提取 SWT
    # m 是分解层数，确保不超过信号长度允许的最大层数
    max_level = int(np.log2(T))
    m = max(1, max_level - 2)  # 至少1层，最多 log2(T)-2

    swt_layer = WaveletEmbedding(
        d_channel=C,
        swt=True,
        requires_grad=False,
        wv=wavelet,
        m=m
    ).to(device)

    x_in = x_sample.permute(0, 2, 1)  # (B, C, T)
    coeffs = swt_layer(x_in)  # (B, C, level+1, T)
    # detail_coeffs: 去掉第0层的近似系数，只取细节系数 (B, C, L, T)
    detail_coeffs = coeffs[0, :, 1:, :].cpu().numpy()  # (C, L, T)

    C_actual, L, _ = detail_coeffs.shape
    scales = [2 ** (L - i) for i in range(L)]  # coarse → fine

    if channel_idx != 'all':
        # === 原有单通道逻辑 ===
        if not isinstance(channel_idx, int) or channel_idx < 0 or channel_idx >= C_actual:
            raise ValueError(f"Invalid channel_idx: {channel_idx}. Must be int between 0 and {C_actual - 1} or 'all'.")

        c = channel_idx
        data_to_plot = detail_coeffs[c]  # (L, T)

        fig, ax = plt.subplots(1, 1, figsize=(10, 4))
        im = ax.imshow(
            data_to_plot,
            aspect='auto',
            cmap='RdBu_r',  # 对称色谱，零为中心
            interpolation='nearest',
            vmin=-np.max(np.abs(data_to_plot)),  # 对称颜色范围
            vmax=np.max(np.abs(data_to_plot))
        )

        ax.set_yticks(range(L))
        ax.set_yticklabels([f'Scale {s}' for s in scales])
        ax.set_xlabel('Time Step', fontsize=12)
        ax.set_ylabel('SWT Scale (Coarse → Fine)', fontsize=12)
        ax.set_title(f'SWT Coefficients Heatmap ({wavelet}, Channel {c})', fontsize=13)

        cbar = plt.colorbar(im, ax=ax, pad=0.02)
        cbar.set_label('Coefficient Value', rotation=90, labelpad=15)

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=400, bbox_inches='tight')
            print(f"✅ SWT heatmap saved to: {save_path}")
        else:
            plt.show()
        plt.close()

    else:
        # === 新增：全通道逻辑 ===
        print(f"📊 Plotting SWT heatmaps for all {C_actual} channels...")

        # 方案 1: 每个通道一个子图，垂直排列
        # 如果通道很多，图片会很长。可以根据通道数调整布局或分页。
        if C_actual > 15:
            print(f"⚠️ Warning: {C_actual} channels detected. Plotting all might result in a very tall image.")
            print("   Consider selecting specific channels or modifying the layout.")

        fig, axes = plt.subplots(C_actual, 1, figsize=(10, 3 * C_actual), sharex=True)
        if C_actual == 1:
            axes = [axes]

        # 计算所有通道的最大绝对值，用于统一颜色条范围，便于比较
        global_max_abs = np.max(np.abs(detail_coeffs))

        for c in range(C_actual):
            ax = axes[c]
            data_to_plot = detail_coeffs[c]  # (L, T)

            im = ax.imshow(
                data_to_plot,
                aspect='auto',
                cmap='RdBu_r',
                interpolation='nearest',
                vmin=-global_max_abs,
                vmax=global_max_abs
            )

            ax.set_ylabel(f'Ch {c}\nScale', fontsize=10)
            if c == C_actual - 1:  # 只在最后一个子图显示 X 轴标签
                ax.set_xlabel('Time Step', fontsize=12)
            else:
                ax.set_xticklabels([])

            # 只为第一个或最后一个子图添加 Y 轴刻度标签，避免拥挤
            if c == 0:
                ax.set_yticks(range(L))
                ax.set_yticklabels([f'{s}' for s in scales], fontsize=8)
            else:
                ax.set_yticks([])

            # 添加标题（可选，如果通道有名字可以用名字）
            # ax.set_title(f'Channel {c}', fontsize=10, pad=5)

        # 添加一个总的 Colorbar
        # cbar = fig.colorbar(im, ax=axes, orientation='vertical', fraction=0.02, pad=0.01)
        # cbar.set_label('Coefficient Value', rotation=90, labelpad=15)

        # 或者为每个子图单独加 colorbar (如果数值范围差异大)，这里用了统一范围所以加一个总的比较好
        # 为了布局美观，我们把 colorbar 放在右侧
        cbar_ax = fig.add_axes([0.92, 0.15, 0.02, 0.7])  # [left, bottom, width, height]
        cbar = fig.colorbar(im, cax=cbar_ax)
        cbar.set_label('Coefficient Value', rotation=90, labelpad=15, fontsize=12)

        fig.suptitle(f'SWT Coefficients Heatmap ({wavelet}) - All Channels', fontsize=14, fontweight='bold', y=0.995)
        plt.tight_layout(rect=[0, 0.01, 0.9, 1.0])  # 为 suptitle 和 colorbar 留空间

        if save_path:
            # 如果保存，确保目录存在
            os.makedirs(os.path.dirname(save_path), exist_ok=True) if os.path.dirname(save_path) else None
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"✅ SWT heatmap (All Channels) saved to: {save_path}")
        else:
            plt.show()
        plt.close()

    # ===== 分析建议 =====
    if channel_idx == 'all':
        print("\n🔍 Interpretation for All Channels:")
        print("- Look for consistent patterns across channels (e.g., same scales showing high energy).")
        print("- Identify channels with distinct features (e.g., specific periodicities or anomalies).")
        print("- Random noise across all channels may indicate ineffective SWT or unsuitable data.")
    else:
        print("\n🔍 How to interpret the heatmap:")
        print("- **Structured patterns** (e.g., vertical stripes, diagonal lines) → meaningful periodicity")
        print("- **Random noise** (speckled, no clear pattern) → ineffective SWT or unsuitable data")
        print("- **Large coefficients at coarse scales** → long-term trends captured")
        print("- **Sharp spikes at fine scales** → abrupt changes / anomalies detected")


# plot_swt_periods_sci 函数保持不变，因为它主要是画能量柱状图，通常也是针对单通道或平均能量
# 如果需要它 also 支持全通道，可以类似地修改，例如画多个子图或堆叠柱状图
def plot_swt_periods_sci(x_sample, wavelet='db4', k=3, save_path=None, channel_idx=0):
    """
    明亮、清新、SCI 一区风格的 SWT 能量分布图（非暗色）
    (此函数暂未修改为全通道，如需修改可参考 plot_swt_heatmap 的逻辑)
    """
    device = x_sample.device
    B, T, C = x_sample.shape
    assert B == 1, "Only support single sample"

    # 获取选中的周期
    period_list, period_weight = SWT_for_Period(x_sample, k=k, wavelet=wavelet)

    # 提取 SWT 系数
    max_level = int(np.log2(T))
    m = max(1, max_level - 2)
    swt_layer = WaveletEmbedding(
        d_channel=C,
        swt=True,
        requires_grad=False,
        wv=wavelet,
        m=m
    ).to(device)

    x_in = x_sample.permute(0, 2, 1)  # (B, C, T)
    coeffs = swt_layer(x_in)  # (B, C, level+1, T)
    detail_coeffs = coeffs[:, :, 1:, :]  # 去掉近似系数 (B, C, L, T)
    L = detail_coeffs.shape[2]

    # 计算能量
    if channel_idx is not None and isinstance(channel_idx, int):
        energies = torch.sum(detail_coeffs[0, channel_idx] ** 2, dim=-1)  # (L,)
    else:
        # 如果 channel_idx 不是 int (例如 'all')，这里可以改为计算所有通道的平均能量
        # 或者修改函数签名明确支持
        energies = torch.mean(torch.sum(detail_coeffs ** 2, dim=-1),
                              dim=1).squeeze()  # (L,) Mean over Batch and Channel

    energies = energies.cpu().numpy()
    scales = [2 ** (L - i) for i in range(L)]  # coarse → fine

    # ===== 绘图：明亮清新风格 =====
    fig, ax = plt.subplots(1, 1, figsize=(7, 4.5))

    colors = sns.color_palette("pastel", L)

    bars = ax.bar(
        range(1, L + 1),
        energies,
        color=colors,
        edgecolor='gray',
        linewidth=0.6,
        alpha=0.9
    )

    marked = set()
    for i, p in enumerate(period_list):
        if p in scales:
            idx = scales.index(p)
            if p not in marked:
                ax.axvline(
                    x=idx + 1,
                    color='#E74C3C',
                    linestyle='--',
                    linewidth=2.0,
                    label=f'Top-{i + 1} Period = {p}'
                )
                marked.add(p)

    ax.set_xlabel('SWT Scale (Coarse → Fine)', fontsize=13)
    ax.set_ylabel('Energy (L2 Norm)', fontsize=13)
    title_suffix = f"(Avg over Channels)" if not isinstance(channel_idx, int) else f"(Channel {channel_idx})"
    ax.set_title(f'SWT Energy Distribution ({wavelet}) {title_suffix}', fontsize=14, fontweight='semibold')

    ax.set_xticks(range(1, L + 1))
    ax.set_xticklabels([f'{s}' for s in scales], rotation=45, ha='right', fontsize=11)

    if marked:
        ax.legend(loc='upper right', frameon=True, fancybox=True, shadow=False, framealpha=0.95, edgecolor='lightgray',
                  fontsize=11)

    ax.grid(True, linestyle='-', linewidth=0.5, alpha=0.4, color='#cccccc')
    ax.set_axisbelow(True)

    plt.tight_layout()

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True) if os.path.dirname(save_path) else None
        plt.savefig(save_path, dpi=600, bbox_inches='tight', transparent=False)
        print(f"✅ SWT energy plot saved to: {save_path}")
    else:
        plt.show()

    plt.close()