# visualize_graph.py
import torch
import matplotlib.pyplot as plt
import numpy as np
import networkx as nx
from scipy.stats import kendalltau
from matplotlib import cm

from models.TimeCasper import Model


def _compute_full_kendall_tau(x_batch):
    """
    Compute full B x B Kendall tau matrix by flattening each sample to (T*C).
    Matches the logic in Model.build_kendall_graph.
    """
    B, T, C = x_batch.shape
    x_flat = x_batch.view(B, -1).cpu().numpy()  # [B, T*C]
    tau_mat = np.zeros((B, B), dtype=np.float32)

    for i in range(B):
        for j in range(i + 1, B):
            try:
                tau, _ = kendalltau(x_flat[i], x_flat[j])
            except Exception:
                tau = 0.0
            tau = max(tau, 0.0)  # only positive correlation
            tau_mat[i, j] = tau
            tau_mat[j, i] = tau
        tau_mat[i, i] = 1.0

    return torch.tensor(tau_mat, dtype=torch.float32, device=x_batch.device)


def plot_kendall_adjacency_heatmap(x_batch, k=5, save_path=None):
    B, T, C = x_batch.shape
    device = x_batch.device

    # === 构建 DummyArgs（必须与 Model.__init__ 兼容）===
    class DummyArgs:
        def __init__(self):
            self.task_name = 'classification'
            self.seq_len = T
            self.enc_in = C
            self.d_model = 128
            self.e_layers = 2
            self.dropout = 0.1
            self.d_ff = 256
            self.n_heads = 8
            self.factor = 3
            self.embed = 'timeF'
            self.freq = 'h'
            self.activation = 'gelu'
            self.output_attention = False
            self.label_len = 0
            self.pred_len = 0
            self.dec_in = C
            self.c_out = C
            self.num_class = 2
            self.top_k = 3
            self.gnn_k = k
            self.use_gnn = True

    model = Model(DummyArgs()).to(device)


    full_sim = _compute_full_kendall_tau(x_batch).cpu().numpy()

    # 绘制热力图
    fig, ax = plt.subplots(1, 1, figsize=(8, 7))
    im = ax.imshow(full_sim, cmap='Blues', aspect='auto', vmin=0, vmax=1)  # 使用天蓝色方案

    # 添加数值标签（保留两位小数）
    for i in range(B):
        for j in range(B):
            text_color = "white" if full_sim[i, j] > 0.5 else "black"  # 根据背景颜色调整文本颜色
            text = ax.text(j, i, f"{full_sim[i, j]:.2f}",
                           ha="center", va="center", color=text_color, fontsize=9)

    # 设置标题和坐标轴标签
    ax.set_xlabel('Sample Index', fontsize=14)
    ax.set_ylabel('Sample Index', fontsize=14)
    ax.set_title(f'Kendall Tau Similarity Matrix (k={k})', fontsize=16, fontweight='semibold')

    # 调整颜色条
    cbar = plt.colorbar(im, ax=ax, shrink=0.8, pad=0.02)
    cbar.set_label('Kendall τ (≥0)', rotation=90, labelpad=15, fontsize=12)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=600, bbox_inches='tight')
        print(f"✅ Kendall similarity heatmap saved to: {save_path}")
    else:
        plt.show()
    plt.close()

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch

def plot_kendall_graph_sci(x_batch, k=5, save_path=None):
    B, T, C = x_batch.shape
    if B > 30:
        print("ℹ️ Skipping weighted graph (B > 30).")
        return

    device = x_batch.device

    # DummyArgs（仅用于兼容，实际未使用 GNN 构图）
    class DummyArgs:
        def __init__(self):
            self.task_name = 'classification'
            self.seq_len = T
            self.enc_in = C
            self.d_model = 128
            self.e_layers = 2
            self.dropout = 0.1
            self.d_ff = 256
            self.n_heads = 8
            self.factor = 3
            self.embed = 'timeF'
            self.freq = 'h'
            self.activation = 'gelu'
            self.output_attention = False
            self.label_len = 0
            self.pred_len = 0
            self.dec_in = C
            self.c_out = C
            self.num_class = 2
            self.top_k = 5
            self.gnn_k = k
            self.use_gnn = True

    model = Model(DummyArgs()).to(device)
    full_sim = _compute_full_kendall_tau(x_batch).cpu().numpy()

    # === Step 1: 为每个节点选择 top-5 最相似邻居（排除自身）===
    edge_set = set()
    for i in range(B):
        sim_row = full_sim[i].copy()
        sim_row[i] = -np.inf  # 排除自己
        top_j = np.argsort(sim_row)[-5:][::-1]  # top 5
        for j in top_j:
            # 无向图：只保留 i < j 避免重复
            if i != j:
                edge_set.add((min(i, j), max(i, j)))

    # === Step 2: 正多边形布局 ===
    radius = 1.0
    angles = [(2 * np.pi * n / B) for n in range(B)]
    pos = {i: (radius * np.cos(a), radius * np.sin(a)) for i, a in enumerate(angles)}

    # === Step 3: 绘图 ===
    plt.figure(figsize=(8, 8))
    ax = plt.gca()

    node_radius = 0.045  # 节点圆半径
    cmap = plt.cm.get_cmap('tab20', B) if B <= 20 else plt.cm.get_cmap('Set3', B)
    node_colors = [cmap(i) for i in range(B)]

    # 绘制节点
    for i in range(B):
        circle = plt.Circle(pos[i], node_radius, color=node_colors[i], ec='black', lw=1.0)
        ax.add_patch(circle)
        ax.text(pos[i][0], pos[i][1], str(i), ha='center', va='center',
                fontsize=9, fontweight='bold', color='white')

    # === Step 4: 绘制连线（从圆周到圆周）===
    for (i, j) in edge_set:
        x1, y1 = pos[i]
        x2, y2 = pos[j]

        dx, dy = x2 - x1, y2 - y1
        dist = np.hypot(dx, dy)
        if dist == 0:
            continue

        ux, uy = dx / dist, dy / dist

        # 起点：从 i 的圆周出发
        start = (x1 + node_radius * ux, y1 + node_radius * uy)
        # 终点：在 j 的圆周处结束
        end = (x2 - node_radius * ux, y2 - node_radius * uy)

        ax.plot([start[0], end[0]], [start[1], end[1]],
                color='black', lw=1.2, zorder=1)

    # === Finalize ===
    ax.set_xlim(-1.25, 1.25)
    ax.set_ylim(-1.25, 1.25)
    ax.set_aspect('equal')
    ax.axis('off')
    plt.title(f'Kendall Graph (Top-5 Neighbors, B={B})', fontsize=16, fontweight='semibold')
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=600, bbox_inches='tight')
        print(f"✅ Weighted Kendall graph saved to: {save_path}")
    else:
        plt.show()
    plt.close()