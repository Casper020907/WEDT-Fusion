# utils/visualization.py
import os
import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.graphics.tsaplots import plot_acf
from typing import Optional, List, Tuple
from collections import OrderedDict

from models.TimeCasper import WaveletEmbedding

# 顶刊绘图风格
sns.set(style="ticks")
plt.rcParams.update({
    "font.family": "serif",
    "font.size": 12,
    "axes.titlesize": 14,
    "axes.labelsize": 12,
    "legend.fontsize": 11,
    "figure.figsize": (8, 5),
    "savefig.dpi": 300,
    "figure.dpi": 150,
    "text.usetex": False  # 若无 LaTeX 可设为 False
})


class FeatureExtractor:
    """用于从任意层提取中间特征的 Hook 工具"""
    def __init__(self):
        self.feature = None

    def hook(self, module, input, output):
        self.feature = output.detach()

    def register_hook(self, module):
        return module.register_forward_hook(self.hook)


class Analyzer:
    def __init__(
        self,
        model: torch.nn.Module,
        device: torch.device = torch.device("cpu"),
        save_dir: str = "figures"
    ):
        self.model = model.to(device).eval()
        self.device = device
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

    def plot_loss(
        self,
        train_losses: List[float],
        val_losses: List[float],
        title: str = "Training and Validation Loss",
        save_name: str = "loss_curve.png"
    ):
        plt.figure(figsize=(8, 5))
        plt.plot(train_losses, label='Training Loss', linewidth=2, color='#1f77b4')
        plt.plot(val_losses, label='Validation Loss', linewidth=2, color='#ff7f0e')
        plt.title(title)
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        plt.tight_layout()
        save_path = os.path.join(self.save_dir, save_name)
        plt.savefig(save_path, bbox_inches='tight')
        plt.show()

    def plot_autocorrelation(
        self,
        series: np.ndarray,
        lags: int = 50,
        channel: int = 0,
        save_name: str = "acf.png"
    ):
        if series.ndim > 1:
            series = series[:, channel]
        plt.figure(figsize=(8, 4))
        plot_acf(series, lags=lags, alpha=0.05)
        plt.title(f'Autocorrelation (Channel {channel})')
        plt.tight_layout()
        save_path = os.path.join(self.save_dir, save_name)
        plt.savefig(save_path, bbox_inches='tight')
        plt.show()

    def plot_time_series(
        self,
        original: np.ndarray,
        predicted: Optional[np.ndarray] = None,
        channel: int = 0,
        title: str = "Time Series Comparison",
        save_name: str = "time_series.png"
    ):
        if original.ndim > 1:
            original = original[:, channel]
        if predicted is not None and predicted.ndim > 1:
            predicted = predicted[:, channel]

        plt.figure(figsize=(10, 4))
        plt.plot(original, label='Original', linewidth=1.5, color='black')
        if predicted is not None:
            plt.plot(predicted, '--', label='Predicted', linewidth=1.5, color='#d62728')
        plt.title(title)
        plt.xlabel('Time Step')
        plt.ylabel('Value')
        plt.legend()
        plt.tight_layout()
        save_path = os.path.join(self.save_dir, save_name)
        plt.savefig(save_path, bbox_inches='tight')
        plt.show()

    def plot_swt_heatmap(
        self,
        x: torch.Tensor,  # [B, T, C]
        wavelet: str = 'db4',
        k: int = 5,
        channel: int = 0,
        save_name: str = "swt_heatmap.png"
    ):
        from models.TimeCasper import SWT_for_Period  # 替换为你的实际模块名
        B, T, C = x.shape
        coeffs = []
        for b in range(min(B, 1)):  # 只画第一个样本
            x_in = x[b:b+1].permute(0, 2, 1)  # [1, C, T]
            swt_layer = WaveletEmbedding(d_channel=C, swt=True, requires_grad=False, wv=wavelet, m=k).to(x.device)
            with torch.no_grad():
                coeff = swt_layer(x_in)  # [1, C, level+1, T]
            coeffs.append(coeff[0, channel, 1:, :].cpu())  # 只取细节系数

        swt_map = torch.cat(coeffs, dim=0)  # [level, T]
        levels = swt_map.shape[0]
        scales = [2 ** (levels - i) for i in range(levels)]

        plt.figure(figsize=(10, 4))
        im = plt.imshow(swt_map.numpy(), cmap='RdBu_r', aspect='auto')
        plt.colorbar(im, label='SWT Coefficient')
        plt.yticks(range(levels), [f'Scale {s}' for s in scales])
        plt.title('SWT Coefficients Heatmap')
        plt.xlabel('Time Step')
        plt.ylabel('Scale (Coarse → Fine)')
        plt.tight_layout()
        save_path = os.path.join(self.save_dir, save_name)
        plt.savefig(save_path, bbox_inches='tight')
        plt.show()

    def generate_gradcam(
        self,
        x: torch.Tensor,  # [1, T, C]
        target_class: Optional[int] = None,
        target_layer: torch.nn.Module = None
    ) -> np.ndarray:
        """
        手动实现 Grad-CAM（更兼容时序模型）
        """
        if target_layer is None:
            # 默认使用最后一个 TimesBlock 的输出
            target_layer = list(self.model.times_blocks)[-1]

        extractor = FeatureExtractor()
        handle = extractor.register_hook(target_layer)

        x = x.to(self.device)
        x.requires_grad_(True)

        if self.model.task_name == 'classification':
            output = self.model.classification(x, None)
        else:
            raise NotImplementedError("CAM only supported for classification.")

        if target_class is None:
            target_class = output.argmax(dim=1).item()

        score = output[0, target_class]
        self.model.zero_grad()
        score.backward()

        # 获取特征图 [1, T, C]
        feature_map = extractor.feature  # shape depends on where you hook
        if feature_map is None:
            raise RuntimeError("Hook did not capture feature map.")

        # 计算梯度权重（对时间维度平均）
        gradients = x.grad  # 或从 layer grad 获取，此处简化
        if gradients is None:
            # 尝试从 feature_map 的梯度
            feature_map.requires_grad_(True)
            score = output[0, target_class]
            score.backward()
            gradients = feature_map.grad

        weights = torch.mean(gradients, dim=-1, keepdim=True)  # [1, T, 1]
        cam = torch.relu(torch.sum(weights * feature_map, dim=-1))  # [1, T]
        cam = cam / (cam.max() + 1e-8)
        handle.remove()
        return cam[0].cpu().numpy()

    def plot_gradcam(
        self,
        x: torch.Tensor,
        target_class: Optional[int] = None,
        target_layer: torch.nn.Module = None,
        title: str = "Grad-CAM",
        save_name: str = "gradcam.png"
    ):
        cam = self.generate_gradcam(x, target_class, target_layer)
        plt.figure(figsize=(10, 2))
        plt.plot(cam, color='red', linewidth=2)
        plt.fill_between(range(len(cam)), cam, color='red', alpha=0.3)
        plt.title(title)
        plt.xlabel('Time Step')
        plt.ylabel('Activation')
        plt.ylim(0, 1)
        plt.tight_layout()
        save_path = os.path.join(self.save_dir, save_name)
        plt.savefig(save_path, bbox_inches='tight')
        plt.show()