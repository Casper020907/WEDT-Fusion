import os
import subprocess
import argparse
import json
import sys

# ==============================================================================
# 1. 超参数配置中心 (基于你提供的历史最佳命令)
# ==============================================================================
# 格式: '数据集名称': { '参数名': 值, ... }
# 未列出的参数将使用默认值 (在 base_command 中定义)
DATASET_HYPERPARAMS = {

    # 'ArticularyWordRecognition': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/ArticularyWordRecognition',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 32,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'AtrialFibrillation': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/AtrialFibrillation',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 32,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 30
    # },
    # 'SpokenArabicDigits': {  # ArabicDigits
    #     'root_path': './dataset1/Multivariate2018_arff_csv/SpokenArabicDigits/',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 32,
    #     'top_k': 2, 'learning_rate': 0.001, 'train_epochs': 60, 'patience': 20
    # },
    # 'CharacterTrajectories': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/CharacterTrajectories',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 64, 'd_ff': 128,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'EthanolConcentration': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/EthanolConcentration',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'PhonemeSpectra': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/PhonemeSpectra',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 32, 'd_model': 64, 'd_ff': 64,
    #     'top_k': 5, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'Epilepsy': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/Epilepsy',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 16, 'd_ff': 32,
    #     'top_k': 5, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'LSST': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/LSST',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 32, 'd_model': 64, 'd_ff': 128,
    #     'top_k': 5, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'ERing': {
    #     'root_path': 'dataset1/Multivariate2018_arff_csv/ERing',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'Cricket': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/Cricket',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'FingerMovements': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/FingerMovements',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 80, 'patience': 20
    # },
    # 'Heartbeat': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/Heartbeat/',
    #     'data': 'UEARAW', 'e_layers': 3, 'batch_size': 16, 'd_model': 16, 'd_ff': 32,
    #     'top_k': 1, 'dropout': 0.1, 'learning_rate': 0.001, 'train_epochs': 40, 'patience': 10
    # },
    # 'Handwriting': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/Handwriting/',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20, 'dropout': 0.3
    # },
    # 'StandWalkJump': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/StandWalkJump',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    #
    # 'BasicMotions': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/BasicMotions',
    #     'data': 'UEARAW', 'e_layers': 6, 'batch_size': 16, 'd_model': 64, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 30
    # },
    # 'SelfRegulationSCP1': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/SelfRegulationSCP1/',
    #     'data': 'UEARAW', 'e_layers': 3, 'batch_size': 16, 'd_model': 16, 'd_ff': 32,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 50, 'patience': 10
    # },
    # 'SelfRegulationSCP2': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/SelfRegulationSCP2/',
    #     'data': 'UEARAW', 'e_layers': 3, 'batch_size': 16, 'd_model': 32, 'd_ff': 32,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 10, 'dropout': 0.3
    # },
    # 'Libras': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/Libras',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 64, 'd_ff': 128,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'HandMovementDirection': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/HandMovementDirection',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'JapaneseVowels': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/JapaneseVowels/',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 16, 'd_ff': 32,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 60, 'patience': 10
    # },
    # 'RacketSports': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/RacketSports',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 32, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'NATOPS': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/NATOPS',
    #     'data': 'UEARAW', 'e_layers': 3, 'batch_size': 16, 'd_model': 64, 'd_ff': 64,
    #     'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },
    # 'PenDigits': {
    #     'root_path': './dataset1/Multivariate2018_arff_csv/PenDigits',
    #     'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 64, 'd_ff': 128,
    #     'top_k': 2, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    # },

    'UWaveGestureLibrary': {
        'root_path': './dataset1/Multivariate2018_arff_csv/UWaveGestureLibrary',
        'data': 'UEARAW',
        'e_layers': 2,
        'batch_size': 16,
        'd_model': 32,
        'd_ff': 64,
        'top_k': 3,
        'learning_rate': 0.001,
        'train_epochs': 100,
        'patience': 20
    },
    'MotorImagery': {
        'root_path': './dataset1/Multivariate2018_arff_csv/MotorImagery',
        'data': 'UEARAW', 'e_layers': 2, 'batch_size': 4, 'd_model': 16, 'd_ff': 16,
        'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 300, 'patience': 50, 'dropout': 0.3
    },
    'PEMS-SF': {
        'root_path': './dataset1/Multivariate2018_arff_csv/PEMS-SF/',
        'data': 'UEARAW', 'e_layers': 2, 'batch_size': 8, 'd_model': 32, 'd_ff': 32,
        'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 200, 'patience': 50, 'dropout': 0.3
    },
    'FaceDetection': {
        'root_path': './dataset/HAPT/FaceDetection',
        'data': 'UEA', 'e_layers': 2, 'batch_size': 16, 'd_model': 64, 'd_ff': 128,
        'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 100, 'patience': 20
    },
    'DuckDuckGeese': {
        'root_path': './dataset1/Multivariate2018_arff_csv/DuckDuckGeese',
        'data': 'UEARAW', 'e_layers': 2, 'batch_size': 16, 'd_model': 64, 'd_ff': 128,
        'top_k': 3, 'learning_rate': 0.001, 'train_epochs': 80, 'patience': 20
    }
}

# 定义消融配置
ABLATION_CONFIGS = [
    # {'name': 'Full', 'args': {}},  # 增加一个完整模型作为基准
    {'name': 'w/o_Wavelet', 'args': {'no_wavelet': True}},
    {'name': 'w/o_Adaptive', 'args': {'no_adaptive': True}},
    {'name': 'w/o_BranchA', 'args': {'no_branch_a': True}},
    {'name': 'w/o_BranchB', 'args': {'no_branch_b': True}},
    {'name': 'w/o_SMEA', 'args': {'no_smea': True}},
    {'name': 'SMEA_Uni', 'args': {'smea_uni': True}},
    {'name': 'w/o_GNN', 'args': {'no_gnn': True}},
    {'name': 'GNN_Static', 'args': {'gnn_static': True}},
]

import subprocess
import json
import os
import sys
import time


def run_experiment(dataset, config_name, config_args, base_cmd, specific_params):
    setting_suffix = f"{config_name}" if config_name != 'Full' else "Full"

    # 1. 构建命令
    cmd = base_cmd + [
        '--task_name', 'classification',
        '--is_training', '1',
        '--model_id', dataset,
        '--model', 'TimeCasper',
        '--des', f'Ablation_{setting_suffix}',
        '--itr', '1',
        '--num_workers', '0',
        '--setting_name', f"{dataset}_{setting_suffix}",
        '--ablation_json', json.dumps(config_args)
    ]

    # 动态注入超参数
    for key, value in specific_params.items():
        cmd.append(f'--{key}')
        cmd.append(str(value))

    # 2. 打印漂亮的开始信息
    print("\n" + "=" * 60)
    print(f"🚀 STARTING: {dataset} | Variant: {config_name}")
    print(
        f"⚙️  Params: d_model={specific_params.get('d_model', '?')}, epochs={specific_params.get('train_epochs', '?')}")
    print("=" * 60)
    # 强制刷新缓冲区，确保立刻看到上面的文字
    sys.stdout.flush()

    try:
        # 3. 运行命令 (关键修改！)
        # text=True: 以文本模式运行
        # check=False: 即使出错也不立刻抛出异常，让我们能捕获返回值
        # stdout/stderr=None: 直接连接到当前终端，实现【实时显示进度条】
        result = subprocess.run(
            cmd,
            text=True,
            check=False,
            stdout=None,  # 直接输出到屏幕
            stderr=None  # 错误也直接输出到屏幕
        )

        # 4. 打印结束信息
        print("\n" + "-" * 60)
        if result.returncode == 0:
            print(f"✅ SUCCESS: {dataset} - {config_name}")
            return True
        else:
            print(f"❌ FAILED: {dataset} - {config_name} (Exit Code: {result.returncode})")
            return False

    except Exception as e:
        print(f"\n💥 EXCEPTION: {dataset} - {config_name}")
        print(f"Error details: {str(e)}")
        return False


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, default=0, help='GPU ID')
    parser.add_argument('--datasets', type=str, nargs='+', default=None,
                        help='Specific datasets to run. If None, run all defined.')
    args = parser.parse_args()

    # 确定要运行的数据集列表
    if args.datasets:
        target_datasets = args.datasets
    else:
        target_datasets = list(DATASET_HYPERPARAMS.keys())

    # 全局基础命令 (不包含特定数据集的参数)
    base_command = [
        'python', 'run.py',
        '--use_gpu', 'True',
        '--gpu', str(args.gpu)
    ]

    success_count = 0
    total_count = len(target_datasets) * len(ABLATION_CONFIGS)

    print(f"📅 Starting Smart Ablation Study on {len(target_datasets)} datasets.")
    print(f"Total experiments: {total_count}")
    print(f"Using GPU: {args.gpu}")

    for ds in target_datasets:
        if ds not in DATASET_HYPERPARAMS:
            print(f"⚠️ Warning: No hyperparams defined for {ds}. Skipping...")
            continue

        ds_params = DATASET_HYPERPARAMS[ds]

        for cfg in ABLATION_CONFIGS:
            if run_experiment(ds, cfg['name'], cfg['args'], base_command, ds_params):
                success_count += 1

            # 显式清理显存 (可选，subprocess 通常会自动清理，但加上更保险)
            # os.system('nvidia-smi --gpu-reset')

    print(f"\n✅ Completed: {success_count}/{total_count} experiments.")
    print("📊 Results saved in ./checkpoints and ./results")
