from torch.utils.tensorboard import SummaryWriter
from data_provider.data_factory import data_provider
from exp.exp_basic import Exp_Basic
from utils.tools import EarlyStopping, cal_accuracy
import torch
import torch.nn as nn
from torch import optim
import os
import time
import warnings
import numpy as np
import matplotlib.pyplot as plt
# 可视化模块（按需保留）
from utils.visualize_attention import visualize_cross_attention
# from utils.visualize_graph import plot_kendall_graph_sci, plot_kendall_adjacency_heatmap
from utils.visualize_periods import plot_swt_periods_sci, plot_swt_heatmap

warnings.filterwarnings('ignore')


from sklearn.preprocessing import StandardScaler

def preprocess_dataset(dataset):
    """
    对单个 UEAloader / Dataset 实例进行标准化（in-place）
    假设 dataset.data_x 是 (B, T, C) 的 NumPy array
    """

    if not hasattr(dataset, 'data_x'):
        raise AttributeError("Dataset must have 'data_x' attribute")

    x = dataset.data_x  # shape: (B, T, C)
    B, T, C = x.shape

    # reshape to (B*T, C) for channel-wise standardization
    x_flat = x.reshape(-1, C)
    scaler = StandardScaler()
    x_scaled = scaler.fit_transform(x_flat).reshape(B, T, C)

    # 替换原数据（in-place）
    dataset.data_x = x_scaled
    return scaler  # 返回 scaler 用于测试集
def apply_scaler_to_dataset(dataset, scaler):
    x = dataset.data_x
    B, T, C = x.shape
    x_flat = x.reshape(-1, C)
    x_scaled = scaler.transform(x_flat).reshape(B, T, C)
    dataset.data_x = x_scaled

class Exp_Classification(Exp_Basic):
    def __init__(self, args):
        super(Exp_Classification, self).__init__(args)

    def _build_model(self):
        train_data, train_loader = self._get_data(flag='TRAIN')
        test_data, test_loader = self._get_data(flag='TEST')
        ablation_cfg = getattr(self.args, 'ablation_config', None)
        self.args.seq_len = max(train_data.max_seq_len, test_data.max_seq_len)
        self.args.pred_len = 0
        self.args.enc_in = train_data.feature_df.shape[1]
        self.args.num_class = len(train_data.class_names)
        # WEDT-FUsion
        model = self.model_dict[self.args.model].Model(self.args).float()
        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model
        #ablation
        # from models.TimeCasper import Model
        # model = Model(self.args, ablation_config=ablation_cfg).float()
        # if self.args.use_multi_gpu and self.args.use_gpu:
        #     model = nn.DataParallel(model, device_ids=self.args.device_ids)
        # return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _select_optimizer(self):
        return optim.RAdam(self.model.parameters(), lr=self.args.learning_rate)

    def _select_criterion(self):
        return nn.CrossEntropyLoss()

    def vali(self, vali_data, vali_loader, criterion):
        total_loss = []
        preds = []
        trues = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, label, padding_mask) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                padding_mask = padding_mask.float().to(self.device)
                label = label.to(self.device)

                outputs = self.model(batch_x, padding_mask, None, None)
                loss = criterion(outputs, label.long().squeeze(-1))
                total_loss.append(loss.item())
                preds.append(outputs.detach())
                trues.append(label)

        total_loss = np.average(total_loss)
        preds = torch.cat(preds, 0)
        trues = torch.cat(trues, 0)
        probs = torch.softmax(preds, dim=1)
        predictions = torch.argmax(probs, dim=1).cpu().numpy()
        trues = trues.flatten().cpu().numpy()
        accuracy = cal_accuracy(predictions, trues)

        self.model.train()
        return total_loss, accuracy

    from sklearn.preprocessing import StandardScaler


    def train(self, setting):
        train_data, train_loader = self._get_data(flag='TRAIN')
        vali_data, vali_loader = self._get_data(flag='TEST')
        test_data, test_loader = self._get_data(flag='TEST')
        # scaler = preprocess_dataset(train_data)  # 返回训练集的 scaler
        # apply_scaler(vali_data, scaler)
        # apply_scaler(test_data, scaler)
        path = os.path.join(self.args.checkpoints, setting)
        os.makedirs(path, exist_ok=True)
        if hasattr(self.args, 'ablation_config') and self.args.ablation_config:
            suffix = "_".join([f"{k}" for k in self.args.ablation_config.keys()])
            setting = f"{setting}_abl_{suffix}"
        total_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        print(f"Total trainable parameters: {total_params}")

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)
        model_optim = self._select_optimizer()
        criterion = self._select_criterion()

        writer = SummaryWriter(log_dir=os.path.join('runs', setting))

        # ✅ 记录每个 epoch 的指标
        train_losses = []
        vali_losses = []
        test_losses = []
        train_accuracies = []
        val_accuracies = []
        test_accuracies = []

        for epoch in range(self.args.train_epochs):
            train_loss = []
            train_preds = []
            train_trues = []
            self.model.train()
            epoch_time = time.time()

            for i, (batch_x, label, padding_mask) in enumerate(train_loader):
                model_optim.zero_grad()
                batch_x = batch_x.float().to(self.device)
                padding_mask = padding_mask.float().to(self.device)
                label = label.to(self.device)

                outputs = self.model(batch_x, padding_mask, None, None)
                loss = criterion(outputs, label.long().squeeze(-1))
                train_loss.append(loss.item())

                # 收集用于计算训练准确率
                train_preds.append(outputs.detach())
                train_trues.append(label)

                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=4.0)
                model_optim.step()

                if (i + 1) % 100 == 0:
                    print(f"\titers: {i + 1}, epoch: {epoch + 1} | loss: {loss.item():.7f}")

            # --- 计算训练损失和准确率 ---
            avg_train_loss = np.mean(train_loss)
            train_losses.append(avg_train_loss)

            train_preds_cat = torch.cat(train_preds, 0)
            train_trues_cat = torch.cat(train_trues, 0)
            train_probs = torch.softmax(train_preds_cat, dim=1)
            train_predictions = torch.argmax(train_probs, dim=1).cpu().numpy()
            train_trues_flat = train_trues_cat.flatten().cpu().numpy()
            train_acc = cal_accuracy(train_predictions, train_trues_flat)
            train_accuracies.append(train_acc)

            writer.add_scalar('Loss/train', avg_train_loss, epoch)
            writer.add_scalar('Accuracy/train', train_acc, epoch)

            print(f"Epoch: {epoch + 1} cost time: {time.time() - epoch_time:.2f}s")

            # 验证和测试
            vali_loss, val_accuracy = self.vali(vali_data, vali_loader, criterion)
            test_loss, test_accuracy = self.vali(test_data, test_loader, criterion)

            vali_losses.append(vali_loss)
            test_losses.append(test_loss)
            val_accuracies.append(val_accuracy)
            test_accuracies.append(test_accuracy)

            writer.add_scalar('Loss/validation', vali_loss, epoch)
            writer.add_scalar('Loss/test', test_loss, epoch)
            writer.add_scalar('Accuracy/validation', val_accuracy, epoch)
            writer.add_scalar('Accuracy/test', test_accuracy, epoch)

            print(
                f"Epoch: {epoch + 1}, Steps: {train_steps} | "
                f"Train Loss: {avg_train_loss:.3f}, Vali Loss: {vali_loss:.3f}, Test Loss: {test_loss:.3f} | "
                f"Train Acc: {train_acc:.3f}, Vali Acc: {val_accuracy:.3f}, Test Acc: {test_accuracy:.3f}"
            )

            early_stopping(-val_accuracy, self.model, path)
            if early_stopping.early_stop:
                print("Early stopping")
                break

        writer.close()
        # ==============================
        # 📈 绘制 Loss 曲线 (整十倍打点 - 优化版)
        # ==============================
        try:
            epochs_plot = list(range(1, len(train_losses) + 1))
            total_epochs = len(train_losses)

            # 1. 确定打点位置 (0, 10, 20... 以及最后一个点)
            marker_indices = []
            for i, epoch in enumerate(epochs_plot):
                if epoch % 10 == 0:
                    marker_indices.append(i)
            # 确保包含最后一个点
            if total_epochs > 0 and (total_epochs - 1) not in marker_indices:
                marker_indices.append(total_epochs - 1)

            # 提取打点数据
            train_loss_markers = [train_losses[i] for i in marker_indices]
            vali_loss_markers = [vali_losses[i] for i in marker_indices]
            epochs_markers = [epochs_plot[i] for i in marker_indices]

            # 2. 样式设置
            plt.rcParams.update({
                "font.family": "serif", "font.size": 12, "axes.titlesize": 13,
                "axes.labelsize": 12, "legend.fontsize": 11, "xtick.labelsize": 11,
                "ytick.labelsize": 11, "figure.dpi": 150, "savefig.dpi": 600,
                "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
                "axes.linewidth": 1.2, "grid.linewidth": 0.8,
            })

            fig, ax = plt.subplots(figsize=(7, 4.5))
            color_train = '#2E86AB'
            color_vali = '#E76F51'

            # 3. 绘图：先画完整的线 (zorder=1)
            ax.plot(epochs_plot, train_losses, color=color_train, linewidth=1.5,
                    label='Training Loss', alpha=0.9, zorder=1)
            ax.plot(epochs_plot, vali_losses, color=color_vali, linewidth=1.5,
                    label='Validation Loss', alpha=0.9, zorder=1)

            # 4. 绘图：再画小标记点 (zorder=5 确保在最上层)
            # markersize=5 (较小), markeredgewidth=1.0 (细白边)
            ax.plot(epochs_markers, train_loss_markers, color=color_train, marker='o',
                    markersize=5, linestyle='None', markeredgecolor='white',
                    markeredgewidth=1.0, alpha=1.0, zorder=5)
            ax.plot(epochs_markers, vali_loss_markers, color=color_vali, marker='s',
                    markersize=5, linestyle='None', markeredgecolor='white',
                    markeredgewidth=1.0, alpha=1.0, zorder=5)

            ax.set_xlabel('Epoch', fontweight='bold')
            ax.set_ylabel('Loss Value', fontweight='bold')
            ax.set_title('Training and Validation Loss Convergence', pad=15, fontweight='semibold')

            legend = ax.legend(loc='upper right', frameon=True, fancybox=True, shadow=False,
                               facecolor='white', edgecolor='#cccccc', framealpha=0.9)
            legend.get_frame().set_linewidth(1.0)

            ax.grid(True, linestyle='--', linewidth=0.6, color='#E0E0E0', axis='y', alpha=0.8)
            ax.grid(False, axis='x')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['bottom'].set_color('#555555')
            ax.spines['left'].set_color('#555555')

            all_vals = np.concatenate([train_losses, vali_losses])
            y_min, y_max = np.min(all_vals), np.max(all_vals)
            margin = (y_max - y_min) * 0.05 if y_max != y_min else 0.1
            ax.set_ylim(max(0, y_min - margin), y_max + margin)

            loss_curve_path = os.path.join(path, 'loss_curve.png')
            plt.savefig(loss_curve_path, dpi=600, bbox_inches='tight', facecolor='white')
            plt.close()
            print(f"✅ Loss curve saved to: {loss_curve_path}")

        except Exception as e:
            print(f"⚠️ Failed to plot loss curve: {e}")

        # ==============================
        # 📈 绘制 Accuracy 曲线 (整十倍打点 - 优化版)
        # ==============================
        try:
            fig, ax = plt.subplots(figsize=(7, 4.5))
            color_train_acc = '#4C9F70'
            color_test_acc = '#F4A261'

            # 1. 画完整的线
            ax.plot(epochs_plot, train_accuracies, color=color_train_acc, linewidth=1.5,
                    label='Training Accuracy', alpha=0.9, zorder=1)
            ax.plot(epochs_plot, test_accuracies, color=color_test_acc, linewidth=1.5,
                    label='Test Accuracy', alpha=0.9, linestyle='--', zorder=1)

            # 2. 画小标记点
            train_acc_markers = [train_accuracies[i] for i in marker_indices]
            test_acc_markers = [test_accuracies[i] for i in marker_indices]

            ax.plot(epochs_markers, train_acc_markers, color=color_train_acc, marker='o',
                    markersize=5, linestyle='None', markeredgecolor='white',
                    markeredgewidth=1.0, alpha=1.0, zorder=5)
            ax.plot(epochs_markers, test_acc_markers, color=color_test_acc, marker='s',
                    markersize=5, linestyle='None', markeredgecolor='white',
                    markeredgewidth=1.0, alpha=1.0, zorder=5)

            ax.set_xlabel('Epoch', fontweight='bold')
            ax.set_ylabel('Accuracy', fontweight='bold')
            ax.set_title('Training and Test Accuracy Performance', pad=15, fontweight='semibold')

            legend = ax.legend(loc='lower right', frameon=True, fancybox=True, shadow=False,
                               facecolor='white', edgecolor='#cccccc', framealpha=0.9)
            legend.get_frame().set_linewidth(1.0)

            ax.grid(True, linestyle='--', linewidth=0.6, color='#E0E0E0', axis='y', alpha=0.8)
            ax.grid(False, axis='x')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['bottom'].set_color('#555555')
            ax.spines['left'].set_color('#555555')

            ax.set_ylim([0.0, 1.05])

            accuracy_curve_path = os.path.join(path, 'accuracy_curve.png')
            plt.savefig(accuracy_curve_path, dpi=600, bbox_inches='tight', facecolor='white')
            plt.close()
            print(f"✅ Accuracy curve saved to: {accuracy_curve_path}")

            # 保存数据
            np.save(os.path.join(path, 'train_accuracies.npy'), np.array(train_accuracies))
            np.save(os.path.join(path, 'val_accuracies.npy'), np.array(val_accuracies))
            np.save(os.path.join(path, 'test_accuracies.npy'), np.array(test_accuracies))
            np.save(os.path.join(path, 'train_losses.npy'), np.array(train_losses))

        except Exception as e:
            print(f"⚠️ Failed to plot accuracy curve: {e}")
        # 加载最佳模型
        best_model_path = os.path.join(path, 'checkpoint.pth')
        self.model.load_state_dict(torch.load(best_model_path, map_location=self.device))
        print("\n🎨 Generating t-SNE Visualization...")

        # t-sne
        self.plot_tsne(setting)
        return self.model

    def test(self, setting, test=0):
        test_data, test_loader = self._get_data(flag='TEST')
        if test:
            print('Loading model...')
            ckpt_path = os.path.join('./checkpoints', setting, 'checkpoint.pth')
            self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))

        preds, trues = [], []
        self.model.eval()
        with torch.no_grad():
            for batch_x, label, padding_mask in test_loader:
                batch_x = batch_x.float().to(self.device)
                label = label.to(self.device)
                outputs = self.model(batch_x, padding_mask.float().to(self.device), None, None)
                preds.append(outputs.detach())
                trues.append(label)

        preds = torch.cat(preds, 0)
        trues = torch.cat(trues, 0)
        probs = torch.softmax(preds, dim=1)
        predictions = torch.argmax(probs, dim=1).cpu().numpy()
        trues = trues.flatten().cpu().numpy()
        accuracy = cal_accuracy(predictions, trues)

        folder_path = os.path.join('./results', setting)
        os.makedirs(folder_path, exist_ok=True)
        with open(os.path.join(folder_path, 'result_classification.txt'), 'a') as f:
            f.write(f"{setting}\naccuracy: {accuracy:.6f}\n\n")

        print(f'Accuracy: {accuracy:.6f}')
        return

    def plot_time_series_and_spectrum(self, x_enc, sample_index=0, save_dir=None):
        import matplotlib.pyplot as plt
        import numpy as np

        x_numpy = x_enc.detach().cpu().numpy()
        B, T, C = x_numpy.shape
        single_sample = x_numpy[sample_index]

        fig1, axes1 = plt.subplots(C, 1, figsize=(8, 2 * C))
        if C == 1:
            axes1 = [axes1]

        for c in range(C):
            ax = axes1[c]
            channel_data = single_sample[:, c]
            ax.plot(channel_data, color='#1f77b4', linewidth=1.2)
            ax.set_title(f'Time Series - Channel {c}')
            ax.set_xlabel('Time Step')
            ax.set_ylabel('Value')
            ax.grid(True, linestyle='--', alpha=0.5)

        plt.tight_layout()
        if save_dir is not None:
            time_series_path = os.path.join(save_dir, f'time_series_sample{sample_index}.png')
            plt.savefig(time_series_path, dpi=300, bbox_inches='tight')
        else:
            plt.show()
        plt.close(fig1)

        fig2, axes2 = plt.subplots(C, 1, figsize=(8, 2 * C))
        if C == 1:
            axes2 = [axes2]

        for c in range(C):
            ax = axes2[c]
            channel_data = single_sample[:, c]
            fft_result = np.fft.fft(channel_data)
            fft_freq = np.fft.fftfreq(len(channel_data))
            positive_mask = fft_freq > 0
            freqs = fft_freq[positive_mask]
            magnitudes = np.abs(fft_result)[positive_mask]

            ax.plot(freqs, magnitudes, color='#ff7f0e', linewidth=1.2)
            ax.set_title(f'Magnitude Spectrum - Channel {c}')
            ax.set_xlabel('Frequency (cycles per time step)')
            ax.set_ylabel('Magnitude')
            ax.grid(True, linestyle='--', alpha=0.5)

        plt.tight_layout()
        if save_dir is not None:
            spectrum_path = os.path.join(save_dir, f'spectrum_sample{sample_index}.png')
            plt.savefig(spectrum_path, dpi=300, bbox_inches='tight')
        else:
            plt.show()
        plt.close(fig2)

        print(f"✅ Time series and spectrum plots saved to: {save_dir}")

    def visualize_best_model(self, setting):
        """
        【最终完善版】
        1. 保留：时序/频谱、小波分解、Kendall 邻接矩阵
        2. 新增：双向交叉注意力图 (Inception↔TimesNet)、混淆矩阵、置信度、显著性、分支贡献
        3. 移除：t-SNE、样本拓扑图
        """
        print("🔍 Loading best model for comprehensive visualization...")
        ckpt_path = os.path.join(self.args.checkpoints, setting, 'checkpoint.pth')
        if not os.path.exists(ckpt_path):
            ckpt_path = os.path.join(self.args.checkpoints, setting, 'best_model.pth')

        self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))
        self.model.eval()

        test_data, test_loader = self._get_data(flag='TEST')
        viz_dir = os.path.join(self.args.checkpoints, setting, 'visualizations_comprehensive')
        os.makedirs(viz_dir, exist_ok=True)

        all_preds, all_trues, all_probs = [], [], []
        sample_batch_x, sample_labels = None, None

        print("📊 Collecting predictions...")
        with torch.no_grad():
            for i, (batch_x, label, padding_mask) in enumerate(test_loader):
                batch_x = batch_x.float().to(self.device)
                label = label.to(self.device)

                outputs = self.model(batch_x, padding_mask.float().to(self.device), None, None)
                probs = torch.softmax(outputs, dim=1)

                all_preds.append(torch.argmax(probs, dim=1).cpu())
                all_trues.append(label.squeeze().cpu())
                all_probs.append(probs.cpu())

                if sample_batch_x is None:
                    sample_batch_x = batch_x.cpu()
                    sample_labels = label.squeeze().cpu().numpy()

                if len(all_preds) * test_loader.batch_size > 2000: break

        preds_cat = torch.cat(all_preds, 0).numpy()
        trues_cat = torch.cat(all_trues, 0).numpy()
        probs_cat = torch.cat(all_probs, 0).numpy()

        # ==============================
        # 🟢 经典可视化
        # ==============================
        print("\n--- Generating Classic Visualizations ---")

        # 1. 时序与频谱
        try:
            self.plot_time_series_and_spectrum(sample_batch_x, sample_index=0, save_dir=viz_dir)
            print("✅ Time Series & Spectrum saved.")
        except Exception as e:
            print(f"⚠️ Time Series failed: {e}")

        # 2. 小波分解
        try:
            if hasattr(self.args, 'wv'):
                from utils.visualize_periods import plot_swt_periods_sci, plot_swt_heatmap
                x_dev = sample_batch_x[:1].to(self.device)
                plot_swt_periods_sci(x_dev, wavelet=self.args.wv, k=getattr(self.args, 'top_k', 3),
                                     save_path=os.path.join(viz_dir, 'swt_energy_sci.png'), channel_idx=0)
                plot_swt_heatmap(x_dev, wavelet=self.args.wv,
                                 save_path=os.path.join(viz_dir, 'swt_heatmap.png'), channel_idx="all")
                self.plot_wavelet_components(sample_batch_x[:1],
                                             save_path=os.path.join(viz_dir, 'wavelet_components.png'))
                print("✅ SWT Decomposition saved.")
        except Exception as e:
            print(f"⚠️ SWT failed: {e}")

        # 3. Kendall 邻接矩阵
        try:
            from utils.visualize_graph import plot_kendall_adjacency_heatmap
            k_val = getattr(self.args, 'gnn_k', 5)
            plot_kendall_adjacency_heatmap(sample_batch_x, k=k_val,
                                           save_path=os.path.join(viz_dir, 'kendall_adjacency_heatmap.png'))
            print("✅ Kendall Adjacency Heatmap saved.")
        except Exception as e:
            print(f"⚠️ Kendall Heatmap failed: {e}")

        # 4. 【升级】双向交叉注意力图 (替代原来的单向图)
        try:
            self.plot_bidirectional_attention_maps(sample_batch_x[:1].to(self.device),
                                                   save_path=os.path.join(viz_dir, 'bidirectional_attention_maps.png'))
            print("✅ Bidirectional Attention Maps saved.")
        except Exception as e:
            print(f"⚠️ Attention Maps failed: {e}")

        # ==============================
        # 🔴 高级可视化
        # ==============================
        print("\n--- Generating Advanced Visualizations ---")

        # 5. 混淆矩阵
        try:
            self.plot_confusion_matrix(trues_cat, preds_cat, class_names=test_data.class_names,
                                       save_path=os.path.join(viz_dir, 'confusion_matrix.png'))
            print("✅ Confusion Matrix saved.")
        except Exception as e:
            print(f"⚠️ Confusion Matrix failed: {e}")

        # 6. 置信度分布
        try:
            self.plot_confidence_distribution(probs_cat, preds_cat, trues_cat,
                                              save_path=os.path.join(viz_dir, 'confidence_distribution.png'))
            print("✅ Confidence Distribution saved.")
        except Exception as e:
            print(f"⚠️ Confidence Distribution failed: {e}")

        # 7. 显著性热力图
        try:
            self.plot_saliency_map(sample_batch_x.to(self.device), sample_labels,
                                   save_path=os.path.join(viz_dir, 'saliency_map.png'))
            print("✅ Saliency Map saved.")
        except Exception as e:
            print(f"⚠️ Saliency Map failed: {e}")

        # 8. 分支贡献度
        try:
            self.plot_branch_contribution(sample_batch_x.to(self.device), sample_labels,
                                          save_path=os.path.join(viz_dir, 'branch_contribution.png'))
            print("✅ Branch Contribution saved.")
        except Exception as e:
            print(f"⚠️ Branch Contribution failed: {e}")

        print(f"\n🎉 All visualizations saved to: {viz_dir}")

    # ==========================================
    # 🆕 新增：双向注意力图绘制函数
    # ==========================================
    def plot_bidirectional_attention_maps(self, x_enc, save_path=None):
        """
        同时绘制两个方向的 Cross-Attention:
        1. InceptionTime (Q) -> TimesNet (K)
        2. TimesNet (Q) -> InceptionTime (K)
        """
        import seaborn as sns
        import matplotlib.pyplot as plt
        import torch

        self.model.eval()
        x_enc = x_enc.to(self.device)

        with torch.no_grad():
            enc_out = self.model.enc_embedding(x_enc, None)

            # --- 分支前向传播 ---
            times_out = enc_out
            for block in self.model.times_blocks:
                times_out = self.model.layer_norm(block(times_out))

            temp_out = self.model.temp_backbone(enc_out)

            if not hasattr(self.model, 'bidirectional_fusion'):
                print("⚠️ No bidirectional_fusion module found.")
                return

            fusion_layer = self.model.bidirectional_fusion

            # 检查是否有两个方向的注意力模块 (根据你的模型实际命名调整)
            # 假设命名分别为 cross_attn_1to2 (Inception->Times) 和 cross_attn_2to1 (Times->Inception)
            # 如果只有一个模块复用，请根据实际情况调整

            attn_maps = []
            titles = []

            # Direction 1: Inception (Query) -> TimesNet (Key)
            if hasattr(fusion_layer, 'cross_attn_1to2'):
                ca_1 = fusion_layer.cross_attn_1to2
                q1 = ca_1.q_proj(temp_out)
                k1 = ca_1.k_proj(times_out)
                B, T, C = q1.shape
                n_heads = ca_1.n_heads
                D = C // n_heads
                q1 = q1.view(B, T, n_heads, D).transpose(1, 2)
                k1 = k1.view(B, T, n_heads, D).transpose(1, 2)
                scores1 = torch.matmul(q1, k1.transpose(-2, -1)) / (D ** 0.5)
                probs1 = torch.softmax(scores1, dim=-1)
                attn_maps.append(probs1[0, 0].cpu().numpy())
                titles.append('InceptionTime (Q) → TimesNet (K)')

            # Direction 2: TimesNet (Query) -> InceptionTime (Key)
            if hasattr(fusion_layer, 'cross_attn_2to1'):
                ca_2 = fusion_layer.cross_attn_2to1
                q2 = ca_2.q_proj(times_out)
                k2 = ca_2.k_proj(temp_out)
                B, T, C = q2.shape
                n_heads = ca_2.n_heads
                D = C // n_heads
                q2 = q2.view(B, T, n_heads, D).transpose(1, 2)
                k2 = k2.view(B, T, n_heads, D).transpose(1, 2)
                scores2 = torch.matmul(q2, k2.transpose(-2, -1)) / (D ** 0.5)
                probs2 = torch.softmax(scores2, dim=-1)
                attn_maps.append(probs2[0, 0].cpu().numpy())
                titles.append('TimesNet (Q) → InceptionTime (K)')

            # 如果模型只用了一个模块处理双向（较少见），这里做 fallback
            if len(attn_maps) == 0:
                print("⚠️ No cross-attention modules found (expected cross_attn_1to2 and/or cross_attn_2to1).")
                return

        # --- 绘图 ---
        n_maps = len(attn_maps)
        fig, axes = plt.subplots(1, n_maps, figsize=(6 * n_maps, 5))
        if n_maps == 1:
            axes = [axes]

        for i, ax in enumerate(axes):
            sns.heatmap(attn_maps[i], cmap='viridis', cbar=True, ax=ax)
            ax.set_title(titles[i], fontsize=14, fontweight='bold')
            ax.set_xlabel('Key Time Steps', fontsize=12)
            ax.set_ylabel('Query Time Steps', fontsize=12)

        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"✅ Bidirectional attention saved to: {save_path}")

    # ==========================================
    # 🟢 其他辅助函数 (保持原样或微调)
    # ==========================================

    def plot_time_series_and_spectrum(self, x_enc, sample_index=0, save_dir=None):
        import matplotlib.pyplot as plt
        import numpy as np
        x_numpy = x_enc.detach().cpu().numpy()
        B, T, C = x_numpy.shape
        single_sample = x_numpy[sample_index]

        fig1, axes1 = plt.subplots(C, 1, figsize=(8, 2 * C))
        if C == 1: axes1 = [axes1]
        for c in range(C):
            ax = axes1[c]
            ax.plot(single_sample[:, c], color='#1f77b4', linewidth=1.2)
            ax.set_title(f'Time Series - Channel {c}')
            ax.grid(True, linestyle='--', alpha=0.5)
        plt.tight_layout()
        if save_dir:
            plt.savefig(os.path.join(save_dir, f'time_series_sample{sample_index}.png'), dpi=300, bbox_inches='tight')
        plt.close(fig1)

        fig2, axes2 = plt.subplots(C, 1, figsize=(8, 2 * C))
        if C == 1: axes2 = [axes2]
        for c in range(C):
            ax = axes2[c]
            fft_result = np.fft.fft(single_sample[:, c])
            freqs = np.fft.fftfreq(len(single_sample[:, c]))
            mask = freqs > 0
            ax.plot(freqs[mask], np.abs(fft_result)[mask], color='#ff7f0e', linewidth=1.2)
            ax.set_title(f'Spectrum - Channel {c}')
            ax.grid(True, linestyle='--', alpha=0.5)
        plt.tight_layout()
        if save_dir:
            plt.savefig(os.path.join(save_dir, f'spectrum_sample{sample_index}.png'), dpi=300, bbox_inches='tight')
        plt.close(fig2)

    def plot_wavelet_components1(self, x_enc, save_path=None):
        try:
            import pywt
        except ImportError:
            return
        import matplotlib.pyplot as plt
        import numpy as np

        x_np = x_enc.detach().cpu().numpy()[0]
        if x_np.shape[1] == 0: return
        signal = x_np[:, 0]
        if len(signal) < 8: return

        wavelet = 'db4'
        level = min(3, pywt.dwt_max_level(len(signal), pywt.Wavelet(wavelet).dec_len))
        if level == 0: return
        coeffs = pywt.swt(signal, wavelet, level=level)

        fig, axes = plt.subplots(level + 1, 1, figsize=(10, 8), sharex=True)
        axes[0].plot(signal, label='Original', color='black', linewidth=1.5)
        axes[0].legend();
        axes[0].grid(True, alpha=0.3)
        colors = plt.cm.viridis(np.linspace(0.2, 0.8, level))
        for i, (cA, cD) in enumerate(coeffs):
            axes[i + 1].plot(cD, label=f'D{i + 1}', color=colors[i], linewidth=1.2)
            axes[i + 1].legend();
            axes[i + 1].grid(True, alpha=0.3)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()

    def plot_confusion_matrix(self, y_true, y_pred, class_names=None, save_path=None):
        import seaborn as sns
        import matplotlib.pyplot as plt
        from sklearn.metrics import confusion_matrix
        cm = confusion_matrix(y_true, y_pred)
        plt.figure(figsize=(10, 8))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_names, yticklabels=class_names)
        plt.title('Confusion Matrix', fontweight='bold')
        plt.xlabel('Predicted');
        plt.ylabel('True')
        plt.xticks(rotation=45);
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()

    def plot_confidence_distribution(self, probs, preds, trues, save_path=None):
        """
        绘制置信度分布直方图和可靠性图 (修复版：确保图例显示)
        """
        import matplotlib.pyplot as plt
        import numpy as np

        # 创建画布
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))

        max_probs = np.max(probs, axis=1)
        correct_mask = (preds == trues)

        # --- 左图：置信度分布 ---
        ax0 = axes[0]

        # 绘制直方图，务必加上 label 参数
        ax0.hist(max_probs[correct_mask], bins=20, alpha=0.8, color='#4C9F70',
                 label='Correct Predictions', edgecolor='black', linewidth=0.5)
        ax0.hist(max_probs[~correct_mask], bins=20, alpha=0.8, color='#E76F51',
                 label='Incorrect Predictions', edgecolor='black', linewidth=0.5)

        # 设置标题和标签
        ax0.set_title('Confidence Distribution: Correct vs Incorrect', fontsize=14, fontweight='bold')
        ax0.set_xlabel('Prediction Confidence (Max Probability)', fontsize=12, fontweight='bold')
        ax0.set_ylabel('Number of Samples', fontsize=12, fontweight='bold')

        # 【关键修复】添加图例
        ax0.legend(loc='upper left', fontsize=11, frameon=True, fancybox=True, shadow=False, facecolor='white',
                   edgecolor='#cccccc')
        ax0.grid(True, linestyle='--', alpha=0.4, axis='y')
        ax0.set_xlim([0, 1])

        # --- 右图：可靠性图 (Reliability Diagram) ---
        ax1 = axes[1]

        # 分桶计算
        bins = np.linspace(0, 1, 11)
        bin_centers = (bins[:-1] + bins[1:]) / 2
        accuracies = []

        for i in range(len(bins) - 1):
            mask = (max_probs >= bins[i]) & (max_probs < bins[i + 1])
            if np.sum(mask) > 0:
                accuracies.append(np.mean(correct_mask[mask]))
            else:
                accuracies.append(0)

        # 绘制完美校准线
        ax1.plot([0, 1], [0, 1], 'k--', linewidth=2, label='Perfect Calibration')

        # 绘制实际准确率柱状图
        ax1.bar(bin_centers, accuracies, width=0.08, color='#2E86AB',
                edgecolor='black', linewidth=0.5, alpha=0.8, label='Model Accuracy')

        # 设置标题和标签
        ax1.set_title('Reliability Diagram (Calibration)', fontsize=14, fontweight='bold')
        ax1.set_xlabel('Mean Predicted Confidence', fontsize=12, fontweight='bold')
        ax1.set_ylabel('Fraction of Positives (Accuracy)', fontsize=12, fontweight='bold')

        # 【可选】右图也可以加图例，如果不想太乱可以注释掉
        ax1.legend(loc='lower right', fontsize=11, frameon=True, fancybox=True, facecolor='white', edgecolor='#cccccc')

        ax1.set_xlim([0, 1])
        ax1.set_ylim([0, 1.05])  # 留一点顶部空间
        ax1.grid(True, linestyle='--', alpha=0.4, axis='y')

        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight', facecolor='white')
            plt.close()
            print(f"✅ Confidence distribution saved to: {save_path}")
        else:
            plt.show()
    def plot_saliency_map(self, x_enc, labels, save_path=None):
        import matplotlib.pyplot as plt
        import numpy as np
        import torch
        x_enc = x_enc.to(self.device).clone().detach().requires_grad_(True)
        self.model.eval()
        outputs = self.model(x_enc, None, None, None)
        preds = torch.argmax(outputs, dim=1)
        maps = []
        count = min(x_enc.shape[0], 4)
        for i in range(count):
            loss = outputs[i, preds[i]]
            loss.backward(retain_graph=True)
            if x_enc.grad is not None:
                maps.append(x_enc.grad[i].abs().max(dim=1)[0].cpu().numpy())
                x_enc.grad.zero_()
            else:
                maps.append(np.zeros(x_enc.shape[1]))

        fig, axes = plt.subplots(count, 2, figsize=(12, 2 * count))
        if count == 1: axes = axes.reshape(1, 2)
        x_np = x_enc.detach().cpu().numpy()
        for i, ax in enumerate(axes):
            ax[0].plot(x_np[i, :, 0], color='#1f77b4')
            ax[0].set_title(f'Sample {i} (True: {labels[i] if i < len(labels) else "?"}, Pred: {preds[i]})')
            ax[0].grid(True, alpha=0.3)
            ax[1].plot(x_np[i, :, 0], color='lightgray', alpha=0.5)
            ax[1].fill_between(range(len(maps[i])), 0, maps[i], color='#E76F51', alpha=0.6, label='Saliency')
            ax[1].set_title('Saliency Map');
            ax[1].legend(fontsize=8);
            ax[1].grid(True, alpha=0.3)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()

    def plot_branch_contribution(self, x_enc, labels, save_path=None):
        import matplotlib.pyplot as plt
        import numpy as np
        import torch
        self.model.eval()
        x_enc = x_enc.to(self.device)
        with torch.no_grad():
            enc_out = self.model.enc_embedding(x_enc, None)
            t_out = enc_out
            for block in self.model.times_blocks: t_out = self.model.layer_norm(block(t_out))
            e_t = torch.norm(t_out.mean(dim=1), p=2, dim=1).cpu().numpy()
            i_out = self.model.temp_backbone(enc_out)
            e_i = torch.norm(i_out.mean(dim=1), p=2, dim=1).cpu().numpy()

        fig, ax = plt.subplots(figsize=(10, 6))
        idx = np.arange(len(e_t))
        w = 0.35
        ax.bar(idx - w / 2, e_t, w, label='TimesNet Energy', color='#2E86AB')
        ax.bar(idx + w / 2, e_i, w, label='Inception Energy', color='#E76F51')
        ax.set_title('Branch Feature Energy Comparison');
        ax.legend();
        ax.grid(True, axis='y', alpha=0.3)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
    # def plot_wavelet_components(self, x_enc, save_path=None):
    #     """绘制原始信号与 SWT 分解出的主要分量"""
    #     import pywt
    #     import matplotlib.pyplot as plt
    #     import torch.nn.functional as F
    #
    #     x_np = x_enc.detach().cpu().numpy()[0]  # (T, C)
    #     T, C = x_np.shape
    #     channel_idx = 0  # 只画第一个通道
    #     signal = x_np[:, channel_idx]
    #
    #     # 使用 pywt 进行单次分解以获取波形 (为了画图简单，这里用 cpu pywt，实际模型用 gpu)
    #     wavelet = 'db4'
    #     level = 3
    #     coeffs = pywt.swt(signal, wavelet, level=level)
    #
    #     fig, axes = plt.subplots(level + 1, 1, figsize=(10, 8), sharex=True)
    #     axes[0].plot(signal, label='Original', color='black', linewidth=1.5)
    #     axes[0].legend(loc='upper right')
    #     axes[0].set_ylabel('Amplitude')
    #     axes[0].grid(True, alpha=0.3)
    #
    #     colors = plt.cm.viridis(np.linspace(0.2, 0.8, level))
    #     for i, (cA, cD) in enumerate(coeffs):
    #         # cD 是细节系数，cA 是近似系数 (最后一层)
    #         # 注意：pywt.swt 返回顺序是 [(cA1, cD1), (cA2, cD2)...] 还是反过来取决于版本，通常是 (cA, cD)
    #         # 这里我们画细节系数 D_i
    #         ax = axes[i + 1]
    #         ax.plot(cD, label=f'Detail D{i + 1} (Scale {2 ** (i + 1)})', color=colors[i], linewidth=1.2)
    #         ax.legend(loc='upper right')
    #         ax.grid(True, alpha=0.3)
    #         ax.set_ylabel(f'D{i + 1}')
    #
    #     axes[-1].set_xlabel('Time Step')
    #     plt.tight_layout()
    #
    #     if save_path:
    #         plt.savefig(save_path, dpi=300, bbox_inches='tight')
    #         plt.close()
    #     else:
    #         plt.show()
    def plot_wavelet_components(self, x_enc, save_path=None):
        """绘制原始信号与 SWT 分解出的主要分量（修复奇数长度问题）"""
        try:
            import pywt
        except ImportError:
            print("⚠️ pywt not installed, skipping wavelet visualization.")
            return

        import matplotlib.pyplot as plt
        import numpy as np

        x_np = x_enc.detach().cpu().numpy()[0]  # (T, C)
        T, C = x_np.shape
        if C == 0 or T < 4:
            return

        channel_idx = 0  # 只画第一个通道
        signal = x_np[:, channel_idx]

        # ✅【关键修复】确保信号长度为偶数
        if len(signal) % 2 != 0:
            signal = signal[:-1]  # 截断最后一个点，使长度为偶数
        if len(signal) < 4:
            return  # 长度太小无法分解

        wavelet = 'db4'
        max_level = pywt.swt_max_level(len(signal))
        level = min(3, max_level)
        if level < 1:
            return

        try:
            coeffs = pywt.swt(signal, wavelet, level=level)
        except Exception as e:
            print(f"⚠️ SWT failed: {e}")
            return

        fig, axes = plt.subplots(level + 1, 1, figsize=(10, 8), sharex=True)
        if level == 0:
            axes = [axes]

        # 原始信号
        axes[0].plot(signal, label='Original', color='black', linewidth=1.5)
        axes[0].legend(loc='upper right')
        axes[0].set_ylabel('Amplitude')
        axes[0].grid(True, alpha=0.3)

        colors = plt.cm.viridis(np.linspace(0.2, 0.8, level))
        for i, (cA, cD) in enumerate(coeffs):
            ax = axes[i + 1]
            ax.plot(cD, label=f'Detail D{i + 1} (Scale {2 ** (i + 1)})', color=colors[i], linewidth=1.2)
            ax.legend(loc='upper right')
            ax.grid(True, alpha=0.3)
            ax.set_ylabel(f'D{i + 1}')

        axes[-1].set_xlabel('Time Step')
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            plt.close()
        else:
            plt.show()
    def extract_features(self, setting, load_best=True):
        """
        提取测试集样本的高维特征表示，用于 t-SNE 可视化。
        返回: features (N, D), labels (N,)
        """
        print(f"🔍 Extracting features for t-SNE visualization ({setting})...")

        test_data, test_loader = self._get_data(flag='TEST')

        if load_best:
            # 加载最佳模型
            ckpt_path = os.path.join(self.args.checkpoints, setting, 'checkpoint.pth')
            if not os.path.exists(ckpt_path):
                ckpt_path = os.path.join(self.args.checkpoints, setting, 'best_model.pth')

            if os.path.exists(ckpt_path):
                self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))
                print(f"✅ Loaded checkpoint from {ckpt_path}")
            else:
                print("⚠️ Checkpoint not found, using current model weights.")

        self.model.eval()

        all_features = []
        all_labels = []

        with torch.no_grad():
            for i, (batch_x, label, padding_mask) in enumerate(test_loader):
                batch_x = batch_x.float().to(self.device)
                padding_mask = padding_mask.float().to(self.device)
                label = label.to(self.device)

                # --- 关键步骤：前向传播直到获取特征 ---
                # 我们需要复用 classification 方法中的逻辑，但只取 feature

                # 1. Embedding
                enc_out = self.model.enc_embedding(batch_x, None)

                # 2. Two branches
                times_out = enc_out
                for block in self.model.times_blocks:
                    times_out = self.model.layer_norm(block(times_out))

                temp_out = self.model.temp_backbone(enc_out)

                # 3. Fusion
                fused_out = self.model.bidirectional_fusion(temp_out, times_out)

                # 4. Global Pooling (得到全局特征)
                if padding_mask is not None:
                    mask_sum = padding_mask.sum(dim=1, keepdim=True) + 1e-8
                    # 注意：padding_mask 通常是 1 表示有效，0 表示 padding
                    # 如果你的 padding_mask 定义相反，请调整此处逻辑
                    # 假设 padding_mask 是 1 (valid), 0 (pad)
                    fused_feat = (fused_out * padding_mask.unsqueeze(-1)).sum(dim=1) / mask_sum
                else:
                    fused_feat = fused_out.mean(dim=1)

                fused_feat = self.model.class_norm(fused_feat)

                # 5. GNN (如果开启) - 提取 GNN 处理后的特征
                if self.model.task_name == 'classification' and getattr(self.model, 'use_gnn', True):
                    # 需要重新构建图 (因为 build_kendall_graph 依赖原始输入)
                    edge_index = self.model.build_kendall_graph(batch_x, k=getattr(self.model.configs, 'gnn_k', 5))

                    x_gnn = fused_feat
                    x_gnn = torch.nn.functional.relu(self.model.gnn1(x_gnn, edge_index))
                    x_gnn = self.model.gnn_dropout(x_gnn)
                    x_gnn = self.model.gnn2(x_gnn, edge_index)
                    x_gnn = self.model.gnn_norm(x_gnn + fused_feat)
                    final_feat = x_gnn
                else:
                    final_feat = fused_feat

                # 收集数据 (CPU)
                all_features.append(final_feat.cpu())
                all_labels.append(label.squeeze().cpu())

                if len(all_features) * test_loader.batch_size > 3000:
                    # 限制样本数量以防 t-SNE 太慢 (可选)
                    print("⚠️ Sample limit reached for t-SNE speed.")
                    break

        features = torch.cat(all_features, dim=0).numpy()
        labels = torch.cat(all_labels, dim=0).numpy()

        print(f"✅ Features extracted: Shape {features.shape}, Classes {len(np.unique(labels))}")
        return features, labels, test_data.class_names

    def plot_tsne(self, setting, perplexity=30, n_iter=1000, random_state=42):
        """
        执行 t-SNE 降维并绘制散点图 (已修复 class_names 判断逻辑)
        """
        try:
            from sklearn.manifold import TSNE
            import seaborn as sns
            import matplotlib.pyplot as plt
            import pandas as pd
        except ImportError:
            print("❌ Please install: pip install scikit-learn seaborn")
            return

        # 1. 提取特征
        features, labels, class_names = self.extract_features(setting, load_best=True)

        if len(np.unique(labels)) < 2:
            print("⚠️ Only one class found, skipping t-SNE.")
            return

        print("🚀 Running t-SNE dimensionality reduction...")
        # 2. 执行 t-SNE
        tsne = TSNE(n_components=2, perplexity=perplexity, n_iter=n_iter,
                    random_state=random_state, init='pca', learning_rate='auto')
        tsne_results = tsne.fit_transform(features)

        # 3. 准备绘图数据
        df_tsne = pd.DataFrame({
            't-SNE 1': tsne_results[:, 0],
            't-SNE 2': tsne_results[:, 1],
            'Label': labels
        })

        # ✅ 修复核心：安全地检查 class_names
        # 处理 Pandas Index, List, 或 None 的情况
        has_names = False
        if class_names is not None:
            if hasattr(class_names, '__len__'):
                if len(class_names) > 0:
                    has_names = True
            elif hasattr(class_names, '__bool__'):  # 应对某些特殊对象
                try:
                    if bool(class_names): has_names = True
                except:
                    pass

        if has_names:
            try:
                label_map = {i: name for i, name in enumerate(class_names)}
                df_tsne['Class Name'] = df_tsne['Label'].map(label_map)
            except Exception as e:
                print(f"⚠️ Failed to map class names: {e}. Using numeric labels.")
                df_tsne['Class Name'] = df_tsne['Label'].astype(str)
        else:
            df_tsne['Class Name'] = df_tsne['Label'].astype(str)

        # ... (后续的绘图代码保持不变) ...
        # 4. 绘图设置
        plt.rcParams.update({
            "font.family": "serif", "font.size": 12,
            "axes.titlesize": 14, "axes.labelsize": 12,
            "legend.fontsize": 10, "xtick.labelsize": 10, "ytick.labelsize": 10,
            "figure.dpi": 800, "savefig.dpi": 800
        })

        fig, ax = plt.subplots(figsize=(5, 4))

        unique_classes = len(np.unique(labels))
        palette = sns.color_palette("husl", n_colors=unique_classes)

        scatter = sns.scatterplot(
            data=df_tsne,
            x='t-SNE 1', y='t-SNE 2',
            hue='Class Name',
            palette=palette,
            s=40, alpha=0.85,
            edgecolor='black', linewidth=0.5,
            ax=ax, legend='full'
        )

        # 美化图例
        legend = ax.legend(
            title='Classes', title_fontsize=12,
            loc='center left', bbox_to_anchor=(1, 0.45),
            frameon=True, fancybox=True, shadow=False,
            facecolor='white', edgecolor='#cccccc'
        )
        legend.get_frame().set_linewidth(1.0)

        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_color('#555555')
        ax.spines['bottom'].set_color('#555555')
        ax.spines['left'].set_linewidth(1.2)
        ax.spines['bottom'].set_linewidth(1.2)

        ax.set_xlabel('t-SNE Dimension 1', fontweight='bold')
        ax.set_ylabel('t-SNE Dimension 2', fontweight='bold')
        ax.set_title(f't-SNE Visualization of Learned Features', pad=15, fontweight='semibold')
        ax.grid(True, linestyle='--', linewidth=0.5, color='#E0E0E0', alpha=0.5)
        ax.set_axisbelow(True)

        viz_dir = os.path.join(self.args.checkpoints, setting, 'visualizations_comprehensive')
        os.makedirs(viz_dir, exist_ok=True)
        save_path = os.path.join(viz_dir, 'tsne_features.png')

        plt.tight_layout()
        plt.savefig(save_path, dpi=800, bbox_inches='tight', facecolor='white')
        plt.close()

        print(f"✅ t-SNE plot saved to: {save_path}")
