from torch.utils.tensorboard import SummaryWriter
from data_provider.data_factory import data_provider
from exp.exp_basic import Exp_Basic
from utils.tools import EarlyStopping, cal_accuracy
import torch
import torch.nn as nn
from torch import optim
import os
import time
import warnings
import numpy as np
import matplotlib.pyplot as plt
# 可视化模块（按需保留）
from utils.visualize_attention import visualize_cross_attention
from utils.visualize_graph import plot_kendall_graph_sci, plot_kendall_adjacency_heatmap
from utils.visualize_periods import plot_swt_periods_sci, plot_swt_heatmap

warnings.filterwarnings('ignore')


from sklearn.preprocessing import StandardScaler

def preprocess_dataset(dataset):
    """
    对单个 UEAloader / Dataset 实例进行标准化（in-place）
    假设 dataset.data_x 是 (B, T, C) 的 NumPy array
    """

    if not hasattr(dataset, 'data_x'):
        raise AttributeError("Dataset must have 'data_x' attribute")

    x = dataset.data_x  # shape: (B, T, C)
    B, T, C = x.shape

    # reshape to (B*T, C) for channel-wise standardization
    x_flat = x.reshape(-1, C)
    scaler = StandardScaler()
    x_scaled = scaler.fit_transform(x_flat).reshape(B, T, C)

    # 替换原数据（in-place）
    dataset.data_x = x_scaled
    return scaler  # 返回 scaler 用于测试集
def apply_scaler_to_dataset(dataset, scaler):
    x = dataset.data_x
    B, T, C = x.shape
    x_flat = x.reshape(-1, C)
    x_scaled = scaler.transform(x_flat).reshape(B, T, C)
    dataset.data_x = x_scaled
class Exp_Classification(Exp_Basic):
    def __init__(self, args):
        super(Exp_Classification, self).__init__(args)

    def _build_model(self):
        train_data, train_loader = self._get_data(flag='TRAIN')
        test_data, test_loader = self._get_data(flag='TEST')
        self.args.seq_len = max(train_data.max_seq_len, test_data.max_seq_len)
        self.args.pred_len = 0
        self.args.enc_in = train_data.feature_df.shape[1]
        self.args.num_class = len(train_data.class_names)
        model = self.model_dict[self.args.model].Model(self.args).float()
        if self.args.use_multi_gpu and self.args.use_gpu:
            model = nn.DataParallel(model, device_ids=self.args.device_ids)
        return model

    def _get_data(self, flag):
        data_set, data_loader = data_provider(self.args, flag)
        return data_set, data_loader

    def _select_optimizer(self):
        return optim.RAdam(self.model.parameters(), lr=self.args.learning_rate)

    def _select_criterion(self):
        return nn.CrossEntropyLoss()

    def vali(self, vali_data, vali_loader, criterion):
        total_loss = []
        preds = []
        trues = []
        self.model.eval()
        with torch.no_grad():
            for i, (batch_x, label, padding_mask) in enumerate(vali_loader):
                batch_x = batch_x.float().to(self.device)
                padding_mask = padding_mask.float().to(self.device)
                label = label.to(self.device)

                outputs = self.model(batch_x, padding_mask, None, None)
                loss = criterion(outputs, label.long().squeeze(-1))
                total_loss.append(loss.item())
                preds.append(outputs.detach())
                trues.append(label)

        total_loss = np.average(total_loss)
        preds = torch.cat(preds, 0)
        trues = torch.cat(trues, 0)
        probs = torch.softmax(preds, dim=1)
        predictions = torch.argmax(probs, dim=1).cpu().numpy()
        trues = trues.flatten().cpu().numpy()
        accuracy = cal_accuracy(predictions, trues)

        self.model.train()
        return total_loss, accuracy

    from sklearn.preprocessing import StandardScaler


    def train(self, setting):
        train_data, train_loader = self._get_data(flag='TRAIN')
        vali_data, vali_loader = self._get_data(flag='TEST')
        test_data, test_loader = self._get_data(flag='TEST')
        # scaler = preprocess_dataset(train_data)  # 返回训练集的 scaler
        # apply_scaler(vali_data, scaler)
        # apply_scaler(test_data, scaler)
        path = os.path.join(self.args.checkpoints, setting)
       
        os.makedirs(path, exist_ok=True)

        total_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        print(f"Total trainable parameters: {total_params}")

        train_steps = len(train_loader)
        early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)
        model_optim = self._select_optimizer()
        criterion = self._select_criterion()

        writer = SummaryWriter(log_dir=os.path.join('runs', setting))

        # ✅ 记录每个 epoch 的指标
        train_losses = []
        vali_losses = []
        test_losses = []
        train_accuracies = []
        val_accuracies = []
        test_accuracies = []

        for epoch in range(self.args.train_epochs):
            train_loss = []
            train_preds = []
            train_trues = []
            self.model.train()
            epoch_time = time.time()

            for i, (batch_x, label, padding_mask) in enumerate(train_loader):
                model_optim.zero_grad()
                batch_x = batch_x.float().to(self.device)
                padding_mask = padding_mask.float().to(self.device)
                label = label.to(self.device)

                outputs = self.model(batch_x, padding_mask, None, None)
                loss = criterion(outputs, label.long().squeeze(-1))
                train_loss.append(loss.item())

                # 收集用于计算训练准确率
                train_preds.append(outputs.detach())
                train_trues.append(label)

                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=4.0)
                model_optim.step()

                if (i + 1) % 100 == 0:
                    print(f"\titers: {i + 1}, epoch: {epoch + 1} | loss: {loss.item():.7f}")

            # --- 计算训练损失和准确率 ---
            avg_train_loss = np.mean(train_loss)
            train_losses.append(avg_train_loss)

            train_preds_cat = torch.cat(train_preds, 0)
            train_trues_cat = torch.cat(train_trues, 0)
            train_probs = torch.softmax(train_preds_cat, dim=1)
            train_predictions = torch.argmax(train_probs, dim=1).cpu().numpy()
            train_trues_flat = train_trues_cat.flatten().cpu().numpy()
            train_acc = cal_accuracy(train_predictions, train_trues_flat)
            train_accuracies.append(train_acc)

            writer.add_scalar('Loss/train', avg_train_loss, epoch)
            writer.add_scalar('Accuracy/train', train_acc, epoch)

            print(f"Epoch: {epoch + 1} cost time: {time.time() - epoch_time:.2f}s")

            # 验证和测试
            vali_loss, val_accuracy = self.vali(vali_data, vali_loader, criterion)
            test_loss, test_accuracy = self.vali(test_data, test_loader, criterion)

            vali_losses.append(vali_loss)
            test_losses.append(test_loss)
            val_accuracies.append(val_accuracy)
            test_accuracies.append(test_accuracy)

            writer.add_scalar('Loss/validation', vali_loss, epoch)
            writer.add_scalar('Loss/test', test_loss, epoch)
            writer.add_scalar('Accuracy/validation', val_accuracy, epoch)
            writer.add_scalar('Accuracy/test', test_accuracy, epoch)

            print(
                f"Epoch: {epoch + 1}, Steps: {train_steps} | "
                f"Train Loss: {avg_train_loss:.3f}, Vali Loss: {vali_loss:.3f}, Test Loss: {test_loss:.3f} | "
                f"Train Acc: {train_acc:.3f}, Vali Acc: {val_accuracy:.3f}, Test Acc: {test_accuracy:.3f}"
            )

            early_stopping(-val_accuracy, self.model, path)
            if early_stopping.early_stop:
                print("Early stopping")
                break

        writer.close()

        # ==============================
        # 📈 绘制 Loss 曲线（使用内存数据，无贯穿直线）
        # ==============================
        try:
            epochs_plot = list(range(1, len(train_losses) + 1))

            plt.rcParams.update({
                "font.family": "serif",
                "font.size": 11,
                "axes.titlesize": 12,
                "axes.labelsize": 11,
                "legend.fontsize": 10,
                "xtick.labelsize": 10,
                "ytick.labelsize": 10,
                "figure.dpi": 100,
                "savefig.dpi": 300,
                "savefig.bbox": "tight",
                "savefig.pad_inches": 0.05,
            })

            fig, ax = plt.subplots(figsize=(6, 4))
            ax.plot(epochs_plot, train_losses, color='#1f77b4', linewidth=1.5, label='Training Loss')
            ax.plot(epochs_plot, vali_losses, color='#ff7f0e', linewidth=1.5, label='Validation Loss')

            ax.set_xlabel('Epoch')
            ax.set_ylabel('Loss')
            ax.set_title('Training and Validation Loss')
            ax.legend(loc='upper right')
            ax.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)

            all_vals = np.concatenate([train_losses, vali_losses])
            y_min, y_max = np.min(all_vals), np.max(all_vals)
            margin = (y_max - y_min) * 0.1
            ax.set_ylim(max(0, y_min - margin), y_max + margin)
            folder_path = os.path.join('./results', setting)
            loss_curve_path = os.path.join(folder_path, 'loss_curve.png')
            plt.savefig(loss_curve_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"✅ Loss curve saved to: {loss_curve_path}")

        except Exception as e:
            print(f"⚠️ Failed to plot loss curve: {e}")

        # ==============================
        # 📈 绘制 Accuracy 曲线
        # ==============================
        try:
            epochs_plot = list(range(1, len(train_accuracies) + 1))

            plt.rcParams.update({**plt.rcParams})  # 复用上面的设置

            fig, ax = plt.subplots(figsize=(6, 4))
            ax.plot(epochs_plot, train_accuracies, 'o-', color='#2ca02c', markersize=4, linewidth=1.5, label='Training Accuracy')
            ax.plot(epochs_plot, test_accuracies, '^--', color='#ff7f0e', markersize=4, linewidth=1.5, label='Test Accuracy')

            ax.set_xlabel('Epoch')
            ax.set_ylabel('Accuracy')
            ax.set_title('Training and Test Accuracy')
            ax.legend(loc='lower right')
            ax.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.set_ylim([0.0, 1.0])
            folder_path = os.path.join('./results', setting)
            accuracy_curve_path = os.path.join(folder_path, 'accuracy_curve.png')
            plt.savefig(accuracy_curve_path, dpi=300, bbox_inches='tight')
            plt.close()
            print(f"✅ Accuracy curve saved to: {accuracy_curve_path}")

            # ✅ 保存准确率数据
            np.save(os.path.join(path, 'train_accuracies.npy'), np.array(train_accuracies))
            np.save(os.path.join(path, 'val_accuracies.npy'), np.array(val_accuracies))
            np.save(os.path.join(path, 'test_accuracies.npy'), np.array(test_accuracies))
            np.save(os.path.join(path, 'train_losses.npy'), np.array(train_losses))


        except Exception as e:
            print(f"⚠️ Failed to plot accuracy curve: {e}")

        # 加载最佳模型
        best_model_path = os.path.join(path, 'checkpoint.pth')
        self.model.load_state_dict(torch.load(best_model_path, map_location=self.device))
        return self.model

    def test(self, setting, test=0):
        test_data, test_loader = self._get_data(flag='TEST')
        if test:
            print('Loading model...')
            ckpt_path = os.path.join('./checkpoints', setting, 'checkpoint.pth')
            self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))

        preds, trues = [], []
        self.model.eval()
        with torch.no_grad():
            for batch_x, label, padding_mask in test_loader:
                batch_x = batch_x.float().to(self.device)
                label = label.to(self.device)
                outputs = self.model(batch_x, padding_mask.float().to(self.device), None, None)
                preds.append(outputs.detach())
                trues.append(label)

        preds = torch.cat(preds, 0)
        trues = torch.cat(trues, 0)
        probs = torch.softmax(preds, dim=1)
        predictions = torch.argmax(probs, dim=1).cpu().numpy()
        trues = trues.flatten().cpu().numpy()
        accuracy = cal_accuracy(predictions, trues)

        folder_path = os.path.join('./results', setting)
        os.makedirs(folder_path, exist_ok=True)
        with open(os.path.join(folder_path, 'result_classification.txt'), 'a') as f:
            f.write(f"{setting}\naccuracy: {accuracy:.6f}\n\n")

        print(f'Accuracy: {accuracy:.6f}')
        return

    def plot_time_series_and_spectrum(self, x_enc, sample_index=0, save_dir=None):
        import matplotlib.pyplot as plt
        import numpy as np

        x_numpy = x_enc.detach().cpu().numpy()
        B, T, C = x_numpy.shape
        single_sample = x_numpy[sample_index]

        fig1, axes1 = plt.subplots(C, 1, figsize=(8, 2 * C))
        if C == 1:
            axes1 = [axes1]

        for c in range(C):
            ax = axes1[c]
            channel_data = single_sample[:, c]
            ax.plot(channel_data, color='#1f77b4', linewidth=1.2)
            ax.set_title(f'Time Series - Channel {c}')
            ax.set_xlabel('Time Step')
            ax.set_ylabel('Value')
            ax.grid(True, linestyle='--', alpha=0.5)

        plt.tight_layout()
        if save_dir is not None:
            folder_path = os.path.join('./results', setting)
            time_series_path = os.path.join(folder_path, f'time_series_sample{sample_index}.png')
            plt.savefig(time_series_path, dpi=300, bbox_inches='tight')
        else:
            plt.show()
        plt.close(fig1)

        fig2, axes2 = plt.subplots(C, 1, figsize=(8, 2 * C))
        if C == 1:
            axes2 = [axes2]

        for c in range(C):
            ax = axes2[c]
            channel_data = single_sample[:, c]
            fft_result = np.fft.fft(channel_data)
            fft_freq = np.fft.fftfreq(len(channel_data))
            positive_mask = fft_freq > 0
            freqs = fft_freq[positive_mask]
            magnitudes = np.abs(fft_result)[positive_mask]

            ax.plot(freqs, magnitudes, color='#ff7f0e', linewidth=1.2)
            ax.set_title(f'Magnitude Spectrum - Channel {c}')
            ax.set_xlabel('Frequency (cycles per time step)')
            ax.set_ylabel('Magnitude')
            ax.grid(True, linestyle='--', alpha=0.5)

        plt.tight_layout()
        if save_dir is not None:
            spectrum_path = os.path.join(folder_path, f'spectrum_sample{sample_index}.png')
            plt.savefig(spectrum_path, dpi=300, bbox_inches='tight')
        else:
            plt.show()
        plt.close(fig2)

        print(f"✅ Time series and spectrum plots saved to: {save_dir}")
    def visualize_best_model(self, setting):
        print("🔍 Loading best model for visualization...")
        ckpt_path = os.path.join(self.args.checkpoints, setting, 'checkpoint.pth')
        if not os.path.exists(ckpt_path):
            ckpt_path = os.path.join(self.args.checkpoints, setting, 'best_model.pth')
        self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))
        self.model.eval()

        _, vali_loader = self._get_data(flag='TEST')
        batch = next(iter(vali_loader))
        x_enc = batch[0]
        x_batch_for_graph = x_enc.to(self.device)

        viz_dir = os.path.join(self.args.checkpoints, setting, 'visualizations')
        os.makedirs(viz_dir, exist_ok=True)

        try:
            self.plot_time_series_and_spectrum(x_enc, sample_index=0, save_dir=viz_dir)
        except Exception as e:
            print(f"⚠️ Failed to plot time-frequency diagram: {e}")

        try:
            plot_swt_periods_sci(x_enc[:1].to(self.device), wavelet=self.args.wv, k=self.args.top_k,
                                 save_path=os.path.join(folder_path, 'swt_energy_sci.png'), channel_idx=0)
            plot_swt_heatmap(x_enc[:1].to(self.device), wavelet=self.args.wv,
                             save_path=os.path.join(folder_path, 'swt_heatmap.png'), channel_idx=0)
        except Exception as e:
            print(f"⚠️ SWT visualization failed: {e}")

        try:
            k_val = getattr(self.args, 'gnn_k', 5)
            plot_kendall_adjacency_heatmap(x_batch_for_graph, k=k_val,
                                           save_path=os.path.join(folder_path, 'kendall_adjacency_heatmap.png'))
            if x_batch_for_graph.shape[0] <= 30:
                plot_kendall_graph_sci(x_batch_for_graph, k=k_val,
                                       save_path=os.path.join(folder_path, 'kendall_graph_weighted.png'))
        except Exception as e:
            print(f"⚠️ Kendall graph visualization failed: {e}")

        try:
            visualize_cross_attention(self.model, x_enc[:1].to(self.device),
                                      save_path=os.path.join(folder_path, 'cross_attention.png'))
        except Exception as e:
            print(f"⚠️ Cross-attention visualization failed: {e}")

        print(f"✅ All visualizations saved to: {viz_dir}")
# from torch.utils.tensorboard import SummaryWriter
# from data_provider.data_factory import data_provider
# from exp.exp_basic import Exp_Basic
# from utils.tools import EarlyStopping, cal_accuracy
# import torch
# import torch.nn as nn
# from torch import optim
# import os
# import time
# import warnings
# import numpy as np
# import matplotlib.pyplot as plt
# # 可视化模块（按需保留）
# from utils.visualize_attention import visualize_cross_attention
# from utils.visualize_graph import plot_kendall_graph_sci, plot_kendall_adjacency_heatmap
# from utils.visualize_periods import plot_swt_periods_sci, plot_swt_heatmap
#
# warnings.filterwarnings('ignore')
#
#
# from sklearn.preprocessing import StandardScaler
#
# from sklearn.preprocessing import StandardScaler
# import numpy as np
#
#
# def preprocess_dataset(dataset):
#     """Standardize _data_array in-place using training set statistics."""
#     if not hasattr(dataset, '_data_array'):
#         raise AttributeError("Dataset missing '_data_array'")
#
#     x = dataset._data_array  # shape: (total_timesteps, C)
#     # 注意：_data_array 是 flatten 的 (N, C)，不是 (B, T, C)！
#
#     # Standardize across all time steps and samples (channel-wise)
#     scaler = StandardScaler()
#     x_scaled = scaler.fit_transform(x)  # (N, C)
#
#     dataset._data_array = x_scaled.astype(np.float32)
#     return scaler
#
#
# def apply_scaler_to_dataset(dataset, scaler):
#     x = dataset._data_array
#     x_scaled = scaler.transform(x)
#     dataset._data_array = x_scaled.astype(np.float32)
# class Exp_Classification(Exp_Basic):
#     def __init__(self, args):
#         super(Exp_Classification, self).__init__(args)
#
#     def _build_model(self):
#         train_data, train_loader = self._get_data(flag='TRAIN')
#         test_data, test_loader = self._get_data(flag='TEST')
#         self.args.seq_len = max(train_data.max_seq_len, test_data.max_seq_len)
#         self.args.pred_len = 0
#         self.args.enc_in = train_data.feature_df.shape[1]
#         self.args.num_class = len(train_data.class_names)
#         model = self.model_dict[self.args.model].Model(self.args).float()
#         if self.args.use_multi_gpu and self.args.use_gpu:
#             model = nn.DataParallel(model, device_ids=self.args.device_ids)
#         return model
#
#     def _get_data(self, flag):
#         data_set, data_loader = data_provider(self.args, flag)
#         return data_set, data_loader
#
#     def _select_optimizer(self):
#         return optim.RAdam(self.model.parameters(), lr=self.args.learning_rate)
#
#     def _select_criterion(self):
#         return nn.CrossEntropyLoss()
#
#     def vali(self, vali_data, vali_loader, criterion):
#         total_loss = []
#         preds = []
#         trues = []
#         self.model.eval()
#         with torch.no_grad():
#             for i, (batch_x, label, padding_mask) in enumerate(vali_loader):
#                 batch_x = batch_x.float().to(self.device)
#                 padding_mask = padding_mask.float().to(self.device)
#                 label = label.to(self.device)
#
#                 outputs = self.model(batch_x, padding_mask, None, None)
#                 loss = criterion(outputs, label.long().squeeze(-1))
#                 total_loss.append(loss.item())
#                 preds.append(outputs.detach())
#                 trues.append(label)
#
#         total_loss = np.average(total_loss)
#         preds = torch.cat(preds, 0)
#         trues = torch.cat(trues, 0)
#         probs = torch.softmax(preds, dim=1)
#         predictions = torch.argmax(probs, dim=1).cpu().numpy()
#         trues = trues.flatten().cpu().numpy()
#         accuracy = cal_accuracy(predictions, trues)
#
#         self.model.train()
#         return total_loss, accuracy
#
#     from sklearn.preprocessing import StandardScaler
#
#
#     def train(self, setting):
#         train_data, train_loader = self._get_data(flag='TRAIN')
#         vali_data, vali_loader = self._get_data(flag='TEST')
#         test_data, test_loader = self._get_data(flag='TEST')
#
#
#         scaler = preprocess_dataset(train_data)  # 返回训练集的 scaler
#         apply_scaler_to_dataset(vali_data, scaler)
#         apply_scaler_to_dataset(test_data, scaler)
#         path = os.path.join(self.args.checkpoints, setting)
#         os.makedirs(path, exist_ok=True)
#
#         total_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
#         print(f"Total trainable parameters: {total_params}")
#
#         train_steps = len(train_loader)
#         early_stopping = EarlyStopping(patience=self.args.patience, verbose=True)
#         model_optim = self._select_optimizer()
#         criterion = self._select_criterion()
#
#         writer = SummaryWriter(log_dir=os.path.join('runs', setting))
#
#         # ✅ 记录每个 epoch 的指标
#         train_losses = []
#         vali_losses = []
#         test_losses = []
#         train_accuracies = []
#         val_accuracies = []
#         test_accuracies = []
#
#         for epoch in range(self.args.train_epochs):
#             train_loss = []
#             train_preds = []
#             train_trues = []
#             self.model.train()
#             epoch_time = time.time()
#
#             for i, (batch_x, label, padding_mask) in enumerate(train_loader):
#                 model_optim.zero_grad()
#                 batch_x = batch_x.float().to(self.device)
#                 padding_mask = padding_mask.float().to(self.device)
#                 label = label.to(self.device)
#
#                 outputs = self.model(batch_x, padding_mask, None, None)
#                 loss = criterion(outputs, label.long().squeeze(-1))
#                 train_loss.append(loss.item())
#
#                 # 收集用于计算训练准确率
#                 train_preds.append(outputs.detach())
#                 train_trues.append(label)
#
#                 loss.backward()
#                 nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=4.0)
#                 model_optim.step()
#
#                 if (i + 1) % 100 == 0:
#                     print(f"\titers: {i + 1}, epoch: {epoch + 1} | loss: {loss.item():.7f}")
#
#             # --- 计算训练损失和准确率 ---
#             avg_train_loss = np.mean(train_loss)
#             train_losses.append(avg_train_loss)
#
#             train_preds_cat = torch.cat(train_preds, 0)
#             train_trues_cat = torch.cat(train_trues, 0)
#             train_probs = torch.softmax(train_preds_cat, dim=1)
#             train_predictions = torch.argmax(train_probs, dim=1).cpu().numpy()
#             train_trues_flat = train_trues_cat.flatten().cpu().numpy()
#             train_acc = cal_accuracy(train_predictions, train_trues_flat)
#             train_accuracies.append(train_acc)
#
#             writer.add_scalar('Loss/train', avg_train_loss, epoch)
#             writer.add_scalar('Accuracy/train', train_acc, epoch)
#
#             print(f"Epoch: {epoch + 1} cost time: {time.time() - epoch_time:.2f}s")
#
#             # 验证和测试
#             vali_loss, val_accuracy = self.vali(vali_data, vali_loader, criterion)
#             test_loss, test_accuracy = self.vali(test_data, test_loader, criterion)
#
#             vali_losses.append(vali_loss)
#             test_losses.append(test_loss)
#             val_accuracies.append(val_accuracy)
#             test_accuracies.append(test_accuracy)
#
#             writer.add_scalar('Loss/validation', vali_loss, epoch)
#             writer.add_scalar('Loss/test', test_loss, epoch)
#             writer.add_scalar('Accuracy/validation', val_accuracy, epoch)
#             writer.add_scalar('Accuracy/test', test_accuracy, epoch)
#
#             print(
#                 f"Epoch: {epoch + 1}, Steps: {train_steps} | "
#                 f"Train Loss: {avg_train_loss:.3f}, Vali Loss: {vali_loss:.3f}, Test Loss: {test_loss:.3f} | "
#                 f"Train Acc: {train_acc:.3f}, Vali Acc: {val_accuracy:.3f}, Test Acc: {test_accuracy:.3f}"
#             )
#
#             early_stopping(-val_accuracy, self.model, path)
#             if early_stopping.early_stop:
#                 print("Early stopping")
#                 break
#
#         writer.close()
#
#         # ==============================
#         # 📈 绘制 Loss 曲线（使用内存数据，无贯穿直线）
#         # ==============================
#         try:
#             epochs_plot = list(range(1, len(train_losses) + 1))
#
#             plt.rcParams.update({
#                 "font.family": "serif",
#                 "font.size": 11,
#                 "axes.titlesize": 12,
#                 "axes.labelsize": 11,
#                 "legend.fontsize": 10,
#                 "xtick.labelsize": 10,
#                 "ytick.labelsize": 10,
#                 "figure.dpi": 100,
#                 "savefig.dpi": 300,
#                 "savefig.bbox": "tight",
#                 "savefig.pad_inches": 0.05,
#             })
#
#             fig, ax = plt.subplots(figsize=(6, 4))
#             ax.plot(epochs_plot, train_losses, color='#1f77b4', linewidth=1.5, label='Training Loss')
#             ax.plot(epochs_plot, vali_losses, color='#ff7f0e', linewidth=1.5, label='Validation Loss')
#
#             ax.set_xlabel('Epoch')
#             ax.set_ylabel('Loss')
#             ax.set_title('Training and Validation Loss')
#             ax.legend(loc='upper right')
#             ax.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
#             ax.spines['top'].set_visible(False)
#             ax.spines['right'].set_visible(False)
#
#             all_vals = np.concatenate([train_losses, vali_losses])
#             y_min, y_max = np.min(all_vals), np.max(all_vals)
#             margin = (y_max - y_min) * 0.1
#             ax.set_ylim(max(0, y_min - margin), y_max + margin)
#
#             loss_curve_path = os.path.join(path, 'loss_curve.png')
#             plt.savefig(loss_curve_path, dpi=300, bbox_inches='tight')
#             plt.close()
#             print(f"✅ Loss curve saved to: {loss_curve_path}")
#
#         except Exception as e:
#             print(f"⚠️ Failed to plot loss curve: {e}")
#
#         # ==============================
#         # 📈 绘制 Accuracy 曲线
#         # ==============================
#         try:
#             epochs_plot = list(range(1, len(train_accuracies) + 1))
#
#             plt.rcParams.update({**plt.rcParams})  # 复用上面的设置
#
#             fig, ax = plt.subplots(figsize=(6, 4))
#             ax.plot(epochs_plot, train_accuracies, 'o-', color='#2ca02c', markersize=4, linewidth=1.5, label='Training Accuracy')
#             ax.plot(epochs_plot, test_accuracies, '^--', color='#ff7f0e', markersize=4, linewidth=1.5, label='Test Accuracy')
#
#             ax.set_xlabel('Epoch')
#             ax.set_ylabel('Accuracy')
#             ax.set_title('Training and Test Accuracy')
#             ax.legend(loc='lower right')
#             ax.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
#             ax.spines['top'].set_visible(False)
#             ax.spines['right'].set_visible(False)
#             ax.set_ylim([0.0, 1.0])
#
#             accuracy_curve_path = os.path.join(path, 'accuracy_curve.png')
#             plt.savefig(accuracy_curve_path, dpi=300, bbox_inches='tight')
#             plt.close()
#             print(f"✅ Accuracy curve saved to: {accuracy_curve_path}")
#
#             # ✅ 保存准确率数据
#             np.save(os.path.join(path, 'train_accuracies.npy'), np.array(train_accuracies))
#             np.save(os.path.join(path, 'val_accuracies.npy'), np.array(val_accuracies))
#             np.save(os.path.join(path, 'test_accuracies.npy'), np.array(test_accuracies))
#             np.save(os.path.join(path, 'train_losses.npy'), np.array(train_losses))
#
#
#         except Exception as e:
#             print(f"⚠️ Failed to plot accuracy curve: {e}")
#         import pickle
#         with open(os.path.join(path, 'scaler.pkl'), 'wb') as f:
#             pickle.dump(scaler, f)
#         # 加载最佳模型
#         best_model_path = os.path.join(path, 'checkpoint.pth')
#         self.model.load_state_dict(torch.load(best_model_path, map_location=self.device))
#         return self.model
#
#     def test(self, setting, test=0):
#         # 无论 test 参数如何，只要做测试，就加载 best model
#         ckpt_path = os.path.join(self.args.checkpoints, setting, 'checkpoint.pth')
#         print(f'🔍 Loading best model from: {ckpt_path}')
#         self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))
#
#         test_data, test_loader = self._get_data(flag='TEST')
#         import pickle
#         # Load scaler
#         scaler_path = os.path.join(self.args.checkpoints, setting, 'scaler.pkl')
#         with open(scaler_path, 'rb') as f:
#             scaler = pickle.load(f)
#
#
#         test_data_raw, test_loader_raw = self._get_data(flag='TEST')
#
#         # Apply same preprocessing!
#         apply_scaler_to_dataset(test_data_raw, scaler)  # ← 关键！
#         preds, trues = [], []
#         self.model.eval()
#         with torch.no_grad():
#             for batch_x, label, padding_mask in test_loader:
#                 batch_x = batch_x.float().to(self.device)
#                 label = label.to(self.device)
#                 outputs = self.model(batch_x, padding_mask.float().to(self.device), None, None)
#                 preds.append(outputs.detach())
#                 trues.append(label)
#
#         preds = torch.cat(preds, 0)
#         trues = torch.cat(trues, 0)
#         probs = torch.softmax(preds, dim=1)
#         predictions = torch.argmax(probs, dim=1).cpu().numpy()
#         trues = trues.flatten().cpu().numpy()
#         accuracy = cal_accuracy(predictions, trues)
#
#         folder_path = os.path.join('./results', setting)
#         os.makedirs(folder_path, exist_ok=True)
#         with open(os.path.join(folder_path, 'result_classification.txt'), 'a') as f:
#             f.write(f"{setting}\naccuracy: {accuracy:.6f}\n\n")
#
#         print(f'Accuracy: {accuracy:.6f}')
#         return
#
#     def plot_time_series_and_spectrum(self, x_enc, sample_index=0, save_dir=None):
#         import matplotlib.pyplot as plt
#         import numpy as np
#
#         x_numpy = x_enc.detach().cpu().numpy()
#         B, T, C = x_numpy.shape
#         single_sample = x_numpy[sample_index]
#
#         fig1, axes1 = plt.subplots(C, 1, figsize=(8, 2 * C))
#         if C == 1:
#             axes1 = [axes1]
#
#         for c in range(C):
#             ax = axes1[c]
#             channel_data = single_sample[:, c]
#             ax.plot(channel_data, color='#1f77b4', linewidth=1.2)
#             ax.set_title(f'Time Series - Channel {c}')
#             ax.set_xlabel('Time Step')
#             ax.set_ylabel('Value')
#             ax.grid(True, linestyle='--', alpha=0.5)
#
#         plt.tight_layout()
#         if save_dir is not None:
#             time_series_path = os.path.join(save_dir, f'time_series_sample{sample_index}.png')
#             plt.savefig(time_series_path, dpi=300, bbox_inches='tight')
#         else:
#             plt.show()
#         plt.close(fig1)
#
#         fig2, axes2 = plt.subplots(C, 1, figsize=(8, 2 * C))
#         if C == 1:
#             axes2 = [axes2]
#
#         for c in range(C):
#             ax = axes2[c]
#             channel_data = single_sample[:, c]
#             fft_result = np.fft.fft(channel_data)
#             fft_freq = np.fft.fftfreq(len(channel_data))
#             positive_mask = fft_freq > 0
#             freqs = fft_freq[positive_mask]
#             magnitudes = np.abs(fft_result)[positive_mask]
#
#             ax.plot(freqs, magnitudes, color='#ff7f0e', linewidth=1.2)
#             ax.set_title(f'Magnitude Spectrum - Channel {c}')
#             ax.set_xlabel('Frequency (cycles per time step)')
#             ax.set_ylabel('Magnitude')
#             ax.grid(True, linestyle='--', alpha=0.5)
#
#         plt.tight_layout()
#         if save_dir is not None:
#             spectrum_path = os.path.join(save_dir, f'spectrum_sample{sample_index}.png')
#             plt.savefig(spectrum_path, dpi=300, bbox_inches='tight')
#         else:
#             plt.show()
#         plt.close(fig2)
#
#         print(f"✅ Time series and spectrum plots saved to: {save_dir}")
#     def visualize_best_model(self, setting):
#         print("🔍 Loading best model for visualization...")
#         ckpt_path = os.path.join(self.args.checkpoints, setting, 'checkpoint.pth')
#         if not os.path.exists(ckpt_path):
#             ckpt_path = os.path.join(self.args.checkpoints, setting, 'best_model.pth')
#         self.model.load_state_dict(torch.load(ckpt_path, map_location=self.device))
#         self.model.eval()
#
#         _, vali_loader = self._get_data(flag='TEST')
#         batch = next(iter(vali_loader))
#         x_enc = batch[0]
#         x_batch_for_graph = x_enc.to(self.device)
#
#         viz_dir = os.path.join(self.args.checkpoints, setting, 'visualizations')
#         os.makedirs(viz_dir, exist_ok=True)
#
#         try:
#             self.plot_time_series_and_spectrum(x_enc, sample_index=0, save_dir=viz_dir)
#         except Exception as e:
#             print(f"⚠️ Failed to plot time-frequency diagram: {e}")
#
#         try:
#             plot_swt_periods_sci(x_enc[:1].to(self.device), wavelet=self.args.wv, k=self.args.top_k,
#                                  save_path=os.path.join(viz_dir, 'swt_energy_sci.png'), channel_idx=0)
#             plot_swt_heatmap(x_enc[:1].to(self.device), wavelet=self.args.wv,
#                              save_path=os.path.join(viz_dir, 'swt_heatmap.png'), channel_idx=0)
#         except Exception as e:
#             print(f"⚠️ SWT visualization failed: {e}")
#
#         try:
#             k_val = getattr(self.args, 'gnn_k', 5)
#             plot_kendall_adjacency_heatmap(x_batch_for_graph, k=k_val,
#                                            save_path=os.path.join(viz_dir, 'kendall_adjacency_heatmap.png'))
#             if x_batch_for_graph.shape[0] <= 30:
#                 plot_kendall_graph_sci(x_batch_for_graph, k=k_val,
#                                        save_path=os.path.join(viz_dir, 'kendall_graph_weighted.png'))
#         except Exception as e:
#             print(f"⚠️ Kendall graph visualization failed: {e}")
#
#         try:
#             visualize_cross_attention(self.model, x_enc[:1].to(self.device),
#                                       save_path=os.path.join(viz_dir, 'cross_attention.png'))
#         except Exception as e:
#             print(f"⚠️ Cross-attention visualization failed: {e}")
#
#         print(f"✅ All visualizations saved to: {viz_dir}")
