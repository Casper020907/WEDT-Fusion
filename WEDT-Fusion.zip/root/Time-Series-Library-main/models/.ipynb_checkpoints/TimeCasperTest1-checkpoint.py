import torch.nn as nn
import torch.fft
from layers.Embed import DataEmbedding
from layers.Conv_Blocks import Inception_Block_V1, Inception_Block_V2
import numpy as np
import pywt
import torch
import torch.nn.functional as F
import math
#BEST
#v1
#kendall
class WaveletEmbedding(nn.Module):
    def __init__(self, d_channel=32, swt=True, requires_grad=False, wv='db2', m=3,
                 kernel_size=None):
        super().__init__()

        self.swt = swt
        self.d_channel = d_channel
        self.m = m  # Number of decomposition levels of detailed coefficients

        if kernel_size is None:
            self.wavelet = pywt.Wavelet(wv)
            if self.swt:
                h0 = torch.tensor(self.wavelet.dec_lo[::-1], dtype=torch.float32)
                h1 = torch.tensor(self.wavelet.dec_hi[::-1], dtype=torch.float32)
            else:
                h0 = torch.tensor(self.wavelet.rec_lo[::-1], dtype=torch.float32)
                h1 = torch.tensor(self.wavelet.rec_hi[::-1], dtype=torch.float32)
            self.h0 = nn.Parameter(torch.tile(h0[None, None, :], [self.d_channel, 1, 1]), requires_grad=requires_grad)
            self.h1 = nn.Parameter(torch.tile(h1[None, None, :], [self.d_channel, 1, 1]), requires_grad=requires_grad)
            self.kernel_size = self.h0.shape[-1]
        else:
            self.kernel_size = kernel_size
            self.h0 = nn.Parameter(torch.Tensor(self.d_channel, 1, self.kernel_size), requires_grad=requires_grad)
            self.h1 = nn.Parameter(torch.Tensor(self.d_channel, 1, self.kernel_size), requires_grad=requires_grad)
            nn.init.xavier_uniform_(self.h0)
            nn.init.xavier_uniform_(self.h1)

            with torch.no_grad():
                self.h0.data = self.h0.data / torch.norm(self.h0.data, dim=-1, keepdim=True)
                self.h1.data = self.h1.data / torch.norm(self.h1.data, dim=-1, keepdim=True)

    def forward(self, x):
        if self.swt:
            coeffs = self.swt_decomposition(x, self.h0, self.h1, self.m, self.kernel_size)
        else:
            coeffs = self.swt_reconstruction(x, self.h0, self.h1, self.m, self.kernel_size)
        return coeffs

    def swt_decomposition(self, x, h0, h1, depth, kernel_size):

        approx_coeffs = x
        coeffs = []
        dilation = 1
        for _ in range(depth):
            padding = dilation * (kernel_size - 1)
            padding_r = (kernel_size * dilation) // 2
            pad = (padding - padding_r, padding_r)
            approx_coeffs_pad = F.pad(approx_coeffs, pad, "circular")

            detail_coeff = F.conv1d(approx_coeffs_pad, h1, dilation=dilation, groups=x.shape[1])
            approx_coeffs = F.conv1d(approx_coeffs_pad, h0, dilation=dilation, groups=x.shape[1])
            coeffs.append(detail_coeff)
            dilation *= 2
        coeffs.append(approx_coeffs)

        return torch.stack(list(reversed(coeffs)), -2)

    def swt_reconstruction(self, coeffs, g0, g1, m, kernel_size):
        dilation = 2 ** (m - 1)
        approx_coeff = coeffs[:, :, 0, :]
        detail_coeffs = coeffs[:, :, 1:, :]

        for i in range(m):
            detail_coeff = detail_coeffs[:, :, i, :]
            padding = dilation * (kernel_size - 1)
            padding_l = (dilation * kernel_size) // 2
            pad = (padding_l, padding - padding_l)
            approx_coeff_pad = F.pad(approx_coeff, pad, "circular")
            detail_coeff_pad = F.pad(detail_coeff, pad, "circular")

            y = F.conv1d(approx_coeff_pad, g0, groups=approx_coeff.shape[1], dilation=dilation) + \
                F.conv1d(detail_coeff_pad, g1, groups=detail_coeff.shape[1], dilation=dilation)
            approx_coeff = y / 2
            dilation //= 2

        return approx_coeff
def SWT_for_Period(x, k=3, wavelet='db4', level=None):
    """
    使用 WaveletEmbedding（GPU 版 SWT）提取 top-k 显著周期。

    Args:
        x: (B, T, C) - 输入时间序列（PyTorch 张量）
        k: int - 选择 top-k 个显著尺度（周期）
        wavelet: str - 小波基（如 'db4'）
        level: int or None - SWT 分解层数，默认为 floor(log2(T)) - 2

    Returns:
        period_list: List[int] of length k - 选中的周期长度（全局一致）
        period_weight: Tensor (B, k) - 每个样本对这 k 个周期的能量归一化权重
    """
    B, T, C = x.shape
    device = x.device

    # 自动设置最大分解层数（与原逻辑一致）
    if level is None:
        level = int(math.log2(T)) - 2
        level = max(1, min(level, 5))  # 限制在 1~5 层

    # === 关键替换：用 WaveletEmbedding 做批量 SWT 分解 ===
    # 注意：输入需为 (B, C, T)
    x_in = x.permute(0, 2, 1)  # (B, T, C) -> (B, C, T)

    # 创建 SWT 分解器（不训练，固定小波）
    swt_layer = WaveletEmbedding(
        d_channel=C,
        swt=True,
        requires_grad=True,
        wv=wavelet,
        m=level,
        kernel_size=None
    ).to(device)

    with torch.no_grad():  # 如果不需要梯度（通常不需要）
        coeffs = swt_layer(x_in)  # (B, C, level+1, T)
        # coeffs[:, :, 0, :] 是最粗尺度近似（A_level）
        # coeffs[:, :, 1:, :] 是细节系数 D_1 到 D_level？注意顺序！

    # ⚠️ 重要：WaveletEmbedding 输出顺序是 [A_level, D_level, ..., D_1]（reversed）
    # 所以细节系数从索引 1 开始，对应尺度 level → 1
    # 我们需要的是 D_1（细尺度）到 D_level（粗尺度）的能量，对应周期 2, 4, ..., 2^level

    # 提取细节系数：形状 (B, C, level, T)
    detail_coeffs = coeffs[:, :, 1:, :]  # (B, C, level, T)

    # 计算每层能量：sum(cD^2) over T
    # 先平方，再对时间维度求和
    energies = torch.sum(detail_coeffs ** 2, dim=-1)  # (B, C, level)

    # 对通道取平均（与原逻辑一致）
    mean_energies_per_sample = torch.mean(energies, dim=1)  # (B, level)

    # === 全局周期选择（所有样本共享）===
    # 对所有样本在每个尺度上平均能量
    global_mean_energies = mean_energies_per_sample.mean(dim=0)  # (level,)

    # 选 top-k 尺度（注意：索引 0 对应最粗尺度 D_level，周期 = 2^(level)）
    topk_vals, topk_indices = torch.topk(global_mean_energies, k=min(k, level))

    # 将尺度索引转换为周期长度
    # 原理：第 i 层细节系数（i 从 0 到 level-1）对应尺度 = level - i
    #       周期 ≈ 2^(scale) = 2^(level - i)
    # 但更简单的方式：我们按 SWT 标准，第 j 层（j=1..level）周期 = 2^j
    # 而 detail_coeffs 的索引 [0] 是 D_level（j=level），[level-1] 是 D_1（j=1）
    # 所以：实际尺度 j = level - idx
    period_list = []
    for idx in topk_indices:
        scale_j = level - idx.item()  # j ∈ [1, level]
        period = 2 ** scale_j
        period_list.append(period)

    # === 计算每个样本对全局 top-k 周期的权重 ===
    # 提取这些尺度对应的能量
    selected_energies = mean_energies_per_sample[:, topk_indices]  # (B, k')
    period_weight = F.softmax(selected_energies, dim=1)  # (B, k')

    # 补零至 k 维（如果 level < k）
    if period_weight.shape[1] < k:
        pad = torch.zeros(B, k - period_weight.shape[1], device=device)
        period_weight = torch.cat([period_weight, pad], dim=1)
    period_list = period_list[:k]  # 确保不超过 k
    if len(period_list) < k:
        # 补充默认周期（比如 2），避免后续逻辑崩溃（但 classification 通常不会走到这）
        while len(period_list) < k:
            period_list.append(2)
    return period_list, period_weight
import torch
import torch.nn as nn
from typing import List
def get_kernel_sizes(seq_len: int) -> List[int]:
    """根据序列长度自适应选择卷积核大小"""
    if seq_len <= 32:
        return [3, 5, 7]
    elif seq_len <= 128:
        return [5, 9, 15]
    else:
        return [7, 15, 31]
class CrossAttentionFusion(nn.Module):
    """
    Cross-Attention Fusion between two feature sequences.
    Supports: Q from branch A, K/V from branch B (or vice versa).

    Args:
        d_model: hidden dimension
        n_heads: number of attention heads
        dropout: dropout rate
        q_from: 'branch1' or 'branch2' — which branch provides Query
    """

    def __init__(self, d_model, n_heads=4, dropout=0.1, q_from='branch1'):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.q_from = q_from

        # Linear projections
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(dropout)
        self.scale = self.head_dim ** -0.5

    def forward(self, branch1: torch.Tensor, branch2: torch.Tensor):
        """
        Args:
            branch1: [B, T, C]
            branch2: [B, T, C]
        Returns:
            fused: [B, T, C] — enhanced representation of the query branch
        """
        B, T, C = branch1.shape

        if self.q_from == 'branch1':
            Q = self.q_proj(branch1)  # [B, T, C]
            K = self.k_proj(branch2)  # [B, T, C]
            V = self.v_proj(branch2)  # [B, T, C]
        else:
            Q = self.q_proj(branch2)
            K = self.k_proj(branch1)
            V = self.v_proj(branch1)

        # Reshape for multi-head: [B, T, H, D] -> [B*H, T, D]
        Q = Q.view(B, T, self.n_heads, self.head_dim).transpose(1, 2).contiguous().view(B * self.n_heads, T,
                                                                                        self.head_dim)
        K = K.view(B, T, self.n_heads, self.head_dim).transpose(1, 2).contiguous().view(B * self.n_heads, T,
                                                                                        self.head_dim)
        V = V.view(B, T, self.n_heads, self.head_dim).transpose(1, 2).contiguous().view(B * self.n_heads, T,
                                                                                        self.head_dim)

        # Scaled dot-product attention
        attn_scores = torch.bmm(Q, K.transpose(-2, -1)) * self.scale  # [B*H, T, T]
        attn_probs = F.softmax(attn_scores, dim=-1)
        attn_probs = self.dropout(attn_probs)

        # Weighted sum
        out = torch.bmm(attn_probs, V)  # [B*H, T, D]
        out = out.view(B, self.n_heads, T, self.head_dim).transpose(1, 2).contiguous().view(B, T, C)
        out = self.out_proj(out)

        # Add residual connection from the query branch
        if self.q_from == 'branch1':
            out = out + branch1
        else:
            out = out + branch2

        return out
class InceptionTimeBlock(nn.Module):
    def __init__(
            self,
            in_channels: int,
            out_channels: int,
            bottleneck: int = 32,
            kernel_sizes: List[int] = [7, 15, 31]
    ):
        super().__init__()
        n_branches = len(kernel_sizes)
        assert n_branches > 0, "At least one kernel size required"
        assert out_channels >= n_branches, f"out_channels ({out_channels}) too small for {n_branches} branches"

        # ✅ 修复：bottleneck 不超过 in_channels，且不超过 32（安全降维）
        bottleneck = min(bottleneck, in_channels)

        self.bottleneck = (
            nn.Conv1d(in_channels, bottleneck, kernel_size=1)
            if in_channels != bottleneck
            else nn.Identity()
        )

        # 分配输出通道
        base_ch = out_channels // n_branches
        extra_ch = out_channels % n_branches
        branch_chs = [base_ch + (1 if i < extra_ch else 0) for i in range(n_branches)]

        # 创建卷积分支（确保 kernel <= seq_len * 2，避免过度 padding）
        self.convs = nn.ModuleList([
            nn.Conv1d(bottleneck, branch_chs[i], k, padding=k // 2)
            for i, k in enumerate(kernel_sizes)
        ])

        self.bn = nn.BatchNorm1d(out_channels)
        self.activation = nn.ReLU()
        self.residual = (
            nn.Conv1d(in_channels, out_channels, kernel_size=1)
            if in_channels != out_channels
            else nn.Identity()
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.residual(x)
        x = self.bottleneck(x)
        x = torch.cat([conv(x) for conv in self.convs], dim=1)
        x = self.bn(x)
        x = self.activation(x + residual)
        return x


class InceptionTimeEncoder(nn.Module):
    def __init__(
            self,
            d_model: int,
            seq_len: int,
            depth: int = 4,
            bottleneck_base: int = 32  # 建议保留 32 作为上限
    ):
        super().__init__()
        # ✅ 自动选择 kernel sizes based on seq_len
        kernel_sizes = get_kernel_sizes(seq_len)

        layers = []
        for _ in range(depth):
            # ✅ 关键修复：使用 min(bottleneck_base, d_model)
            bottleneck = min(bottleneck_base, d_model)
            layers.append(
                InceptionTimeBlock(
                    in_channels=d_model,
                    out_channels=d_model,
                    bottleneck=bottleneck,
                    kernel_sizes=kernel_sizes
                )
            )
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, C] → [B, C, T]
        x = x.transpose(1, 2)
        x = self.net(x)
        x = x.transpose(1, 2)  # back to [B, T, C]
        return x
class DualAttention(nn.Module):

    def __init__(self, in_channels, reduction=16, kernel_size=7):
        super().__init__()
        # Channel Attention
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        squeeze_channels = max(in_channels // reduction, 1)
        self.channel_excite = nn.Sequential(
            nn.Conv2d(in_channels, squeeze_channels, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(squeeze_channels, in_channels, 1, bias=False),
            nn.Sigmoid()
        )

        #
        # self.spatial_excite = nn.Sequential(
        #     nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False),
        #     nn.Sigmoid()
        # )

    def forward(self, x):
        # Channel Attention
        ch_att = self.avg_pool(x)
        ch_att = self.channel_excite(ch_att)
        x = x * ch_att

        # # Spatial Attention
        # sp_avg = torch.mean(x, dim=1, keepdim=True)
        # sp_max, _ = torch.max(x, dim=1, keepdim=True)
        # sp_att = torch.cat([sp_avg, sp_max], dim=1)
        # sp_att = self.spatial_excite(sp_att)
        # x = x * sp_att

        return x


class BidirectionalCrossAttentionFusion(nn.Module):
    def __init__(self, d_model, n_heads=4, dropout=0.1):
        super().__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"

        # Two cross-attention directions
        self.cross_attn_1to2 = CrossAttentionFusion(d_model, n_heads, dropout,
                                                    q_from='branch1')  # Q=branch1, KV=branch2
        self.cross_attn_2to1 = CrossAttentionFusion(d_model, n_heads, dropout,
                                                    q_from='branch2')  # Q=branch2, KV=branch1

        # FFN after fusion (applied to averaged output)
        hidden_dim = d_model * 2
        self.ffn = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, d_model),
            nn.Dropout(dropout)
        )

        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, branch1: torch.Tensor, branch2: torch.Tensor):
        """
        Args:
            branch1: [B, T, C]  — e.g., InceptionTime
            branch2: [B, T, C]  — e.g., TimesNet
        Returns:
            fused: [B, T, C] — enhanced representation (average of both directions)
        """
        # Direction 1: branch1 attends to branch2
        out1 = self.cross_attn_1to2(branch1, branch2)  # [B, T, C]
        # Direction 2: branch2 attends to branch1
        out2 = self.cross_attn_2to1(branch2, branch1)  # [B, T, C]

        # Option A: Average the two enhanced representations
        fused = (out1 + out2) / 2.0  # [B, T, C]

        # Apply FFN with residual connection
        fused = self.norm1(fused)
        fused = fused + self.ffn(fused)
        fused = self.norm2(fused)

        return fused
class TimesBlock(nn.Module):
    def __init__(self, configs):
        super(TimesBlock, self).__init__()
        self.seq_len = configs.seq_len
        self.pred_len = configs.pred_len
        self.k = configs.top_k
        self.d_model = configs.d_model
        self.d_ff = getattr(configs, 'd_ff', configs.d_model * 4)  # 确保有 d_ff

        # Replace Inception_Block_V1 with your Inception_Block_V2
        self.conv = nn.Sequential(
            Inception_Block_V2(in_channels=configs.d_model, out_channels=self.d_ff, num_kernels=6),
            nn.GELU(),
            Inception_Block_V2(in_channels=self.d_ff, out_channels=configs.d_model, num_kernels=6)
        )

        # Dual Attention (you said removing it helps — feel free to comment out later)
        self.dual_attn = DualAttention(in_channels=configs.d_model, reduction=4)

    def forward(self, x):
        B, T, N = x.size()  # N == d_model
        period_list, period_weight = SWT_for_Period(x, k=self.k, wavelet='db2')
        actual_k = len(period_list)
        total_len = self.seq_len + self.pred_len
        res = []
        for i in range(actual_k):
            period = period_list[i]
            if total_len % period != 0:
                length = ((total_len // period) + 1) * period
                padding = torch.zeros(B, length - total_len, N, device=x.device)
                out = torch.cat([x, padding], dim=1)
            else:
                length = total_len
                out = x

            # Reshape to 2D: [B, N, num_periods, period]
            out = out.reshape(B, length // period, period, N).permute(0, 3, 1, 2).contiguous()
            # Now shape: (B, C=N, H=num_periods, W=period) → compatible with Conv2d

            # Apply your V2 block (works on 4D)
            out = self.conv(out)

            # Apply dual attention (optional — you can remove this line if not needed)
            out = self.dual_attn(out)

            # Reshape back to 1D
            out = out.permute(0, 2, 3, 1).reshape(B, -1, N)
            res.append(out[:, :total_len, :])

        res = torch.stack(res, dim=-1)  # [B, total_len, N, k]
        period_weight = F.softmax(period_weight, dim=1)
        period_weight = period_weight.unsqueeze(1).unsqueeze(1).repeat(1, total_len, N, 1)
        res = torch.sum(res * period_weight, dim=-1)  # [B, total_len, N]

        res = res + x
        return res


import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from scipy.stats import kendalltau
import numpy as np


# def build_kendall_graph(self, x_enc: torch.Tensor, threshold=0.0, k=None):
#     """
#     Build adjacency matrix using Kendall tau correlation between samples in the batch.
#
#     Args:
#         x_enc: [B, T, C] - original input time series (used to compute similarity)
#         threshold: minimum tau to keep an edge (default: 0.0 → keep all positive correlations)
#         k: if not None, keep top-k neighbors per node (overrides threshold)
#
#     Returns:
#         edge_index: [2, E] - sparse edge index for PyG
#     """
#     B, T, C = x_enc.shape
#     device = x_enc.device
#
#     # Flatten each sample to [T*C] for pairwise comparison
#     x_flat = x_enc.view(B, -1).cpu().numpy()  # [B, T*C]
#
#     # Compute Kendall tau matrix [B, B]
#     tau_mat = np.zeros((B, B))
#     for i in range(B):
#         for j in range(i + 1, B):
#             try:
#                 tau, _ = kendalltau(x_flat[i], x_flat[j])
#             except:
#                 tau = 0.0
#             tau = max(tau, 0.0)  # only consider positive correlation
#             tau_mat[i, j] = tau
#             tau_mat[j, i] = tau
#
#     tau_mat = torch.tensor(tau_mat, dtype=torch.float32, device=device)
#
#     if k is not None and k > 0:
#         # Keep top-k neighbors (including self-loop optional)
#         _, topk_indices = torch.topk(tau_mat, k=min(k, B), dim=1)
#         row = torch.arange(B, device=device).unsqueeze(1).repeat(1, topk_indices.size(1))
#         col = topk_indices
#         edge_index = torch.stack([row.view(-1), col.view(-1)], dim=0)
#     else:
#         # Threshold-based
#         mask = tau_mat >= threshold
#         edge_index = torch.nonzero(mask, as_tuple=False).t().contiguous()
#
#     # Optional: add self-loops (GCN usually benefits from them)
#     edge_index = self.add_self_loops(edge_index, num_nodes=B)[0]
#
#     return edge_index
# def add_self_loops(self, edge_index, num_nodes):
#     """Manually add self-loops if not present."""
#     from torch_geometric.utils import add_self_loops as pyg_add
#     return pyg_add(edge_index, num_nodes=num_nodes)
class Model(nn.Module):
    """
    Enhanced Model with dual-branch (TimesNet + InceptionTime) + GNN for time series classification on UEA.
    """

    def __init__(self, configs):
        super(Model, self).__init__()
        self.configs = configs
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.label_len = configs.label_len
        self.pred_len = configs.pred_len
        self.d_model = configs.d_model
        self.class_norm = nn.LayerNorm(configs.d_model)
        # Shared embedding
        self.enc_embedding = DataEmbedding(configs.enc_in, configs.d_model, configs.embed, configs.freq,
                                           configs.dropout)
        self.layer_norm = nn.LayerNorm(configs.d_model)
        self.use_gnn = True
        self.gnn_k = getattr(configs, 'gnn_k', 5)  # 提供默认值更安全
        self.dropout_p = getattr(configs, 'dropout', 0.1)
        # TimesNet blocks
        self.times_blocks = nn.ModuleList([TimesBlock(configs) for _ in range(configs.e_layers)])
        self.learnable_swt = WaveletEmbedding(
            d_channel=configs.enc_in,
            swt=True,
            requires_grad=True,  # ← 关键：设为 True 才能学习！
            wv='db4',
            m=getattr(configs, 'top_k', 5),
            kernel_size=None
        )
        # Task-specific heads
        if self.task_name in ['long_term_forecast', 'short_term_forecast']:
            self.predict_linear = nn.Linear(self.seq_len, self.pred_len + self.seq_len)
            self.projection = nn.Linear(configs.d_model, configs.c_out, bias=True)
        elif self.task_name in ['imputation', 'anomaly_detection']:
            self.projection = nn.Linear(configs.d_model, configs.c_out, bias=True)
        elif self.task_name == 'classification':
            # InceptionTime branch
            self.temp_backbone = InceptionTimeEncoder(
                d_model=configs.d_model,
                depth=4,
                seq_len=configs.seq_len,
            )
            # Bidirectional fusion
            self.bidirectional_fusion = BidirectionalCrossAttentionFusion(
                d_model=configs.d_model,
                n_heads=getattr(configs, 'fusion_n_heads', 4),
                dropout=configs.dropout
            )

            # === GNN 分类头（新增）===
            self.use_gnn = getattr(configs, 'use_gnn', True)  # 默认开启
            if self.use_gnn:
                gnn_hidden = configs.d_model
                self.gnn1 = GCNConv(configs.d_model, gnn_hidden)
                self.gnn2 = GCNConv(gnn_hidden, configs.d_model)
                self.gnn_dropout = nn.Dropout(configs.dropout)
                self.gnn_norm = nn.LayerNorm(configs.d_model)

            self.projection = nn.Linear(configs.d_model, configs.num_class)
            self.dropout = nn.Dropout(configs.dropout)

    def build_kendall_graph(self, x_enc: torch.Tensor, threshold=0.0, k=None):
        """
        Build adjacency matrix using Kendall tau correlation between samples in the batch.

        Args:
            x_enc: [B, T, C] - original input time series (used to compute similarity)
            threshold: minimum tau to keep an edge (default: 0.0 → keep all positive correlations)
            k: if not None, keep top-k neighbors per node (overrides threshold)

        Returns:
            edge_index: [2, E] - sparse edge index for PyG
        """
        B, T, C = x_enc.shape
        device = x_enc.device

        # Flatten each sample to [T*C] for pairwise comparison
        x_flat = x_enc.view(B, -1).cpu().numpy()  # [B, T*C]

        # Compute Kendall tau matrix [B, B]
        tau_mat = np.zeros((B, B))
        for i in range(B):
            for j in range(i + 1, B):
                try:
                    tau, _ = kendalltau(x_flat[i], x_flat[j])
                except:
                    tau = 0.0
                tau = max(tau, 0.0)  # only consider positive correlation
                tau_mat[i, j] = tau
                tau_mat[j, i] = tau

        tau_mat = torch.tensor(tau_mat, dtype=torch.float32, device=device)

        if k is not None and k > 0:
            # Keep top-k neighbors (including self-loop optional)
            _, topk_indices = torch.topk(tau_mat, k=min(k, B), dim=1)
            row = torch.arange(B, device=device).unsqueeze(1).repeat(1, topk_indices.size(1))
            col = topk_indices
            edge_index = torch.stack([row.view(-1), col.view(-1)], dim=0)
        else:
            # Threshold-based
            mask = tau_mat >= threshold
            edge_index = torch.nonzero(mask, as_tuple=False).t().contiguous()

        # Optional: add self-loops (GCN usually benefits from them)
        edge_index = self.add_self_loops(edge_index, num_nodes=B)[0]

        return edge_index

    def add_self_loops(self, edge_index, num_nodes):
        """Manually add self-loops if not present."""
        from torch_geometric.utils import add_self_loops as pyg_add
        return pyg_add(edge_index, num_nodes=num_nodes)

    def classification(self, x_enc, x_mark_enc):
        # Step 1: Embedding
        enc_out = self.enc_embedding(x_enc, None)  # [B, T, C]

        # Step 2: Two branches
        times_out = enc_out
        for block in self.times_blocks:
            times_out = self.layer_norm(block(times_out))  # [B, T, C]

        temp_out = self.temp_backbone(enc_out)  # [B, T, C]

        # Step 3: Fusion
        fused_out = self.bidirectional_fusion(temp_out, times_out)  # [B, T, C]

        # Step 4: Global feature
        if x_mark_enc is not None:
            mask_sum = x_mark_enc.sum(dim=1, keepdim=True) + 1e-8
            fused_feat = (fused_out * x_mark_enc.unsqueeze(-1)).sum(dim=1) / mask_sum
        else:
            fused_feat = fused_out.mean(dim=1)  # [B, C]

        fused_feat = self.class_norm(fused_feat)  # [B, C]

        # Step 5: GNN (only for classification)
        if self.task_name == 'classification' and getattr(self, 'use_gnn', True):
            # Build graph using ORIGINAL input (more meaningful than fused features)
            edge_index = self.build_kendall_graph(x_enc, k=getattr(self.configs, 'gnn_k', 5))

            # GCN forward
            x_gnn = fused_feat
            x_gnn = F.relu(self.gnn1(x_gnn, edge_index))
            x_gnn = self.gnn_dropout(x_gnn)
            x_gnn = self.gnn2(x_gnn, edge_index)
            x_gnn = self.gnn_norm(x_gnn + fused_feat)  # residual
            final_feat = x_gnn
        else:
            final_feat = fused_feat

        # Step 6: Classification head
        output = self.dropout(final_feat)
        output = self.projection(output)  # [B, num_class]
        return output

    # ... [保留你原有的 forecast / imputation / anomaly_detection / forward 方法不变] ...
    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        # （保持原样）
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc.sub(means)
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc.div(stdev)

        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        enc_out = self.predict_linear(enc_out.permute(0, 2, 1)).permute(0, 2, 1)

        for block in self.times_blocks:
            enc_out = self.layer_norm(block(enc_out))

        dec_out = self.projection(enc_out)
        dec_out = dec_out.mul(stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len + self.seq_len, 1))
        dec_out = dec_out.add(means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len + self.seq_len, 1))
        return dec_out

    def imputation(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask):
        # （保持原样）
        means = torch.sum(x_enc, dim=1) / torch.sum(mask == 1, dim=1)
        means = means.unsqueeze(1).detach()
        x_enc = x_enc.sub(means)
        x_enc = x_enc.masked_fill(mask == 0, 0)
        stdev = torch.sqrt(torch.sum(x_enc * x_enc, dim=1) / torch.sum(mask == 1, dim=1) + 1e-5)
        stdev = stdev.unsqueeze(1).detach()
        x_enc = x_enc.div(stdev)

        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        for block in self.times_blocks:
            enc_out = self.layer_norm(block(enc_out))
        dec_out = self.projection(enc_out)

        dec_out = dec_out.mul(stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len + self.seq_len, 1))
        dec_out = dec_out.add(means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len + self.seq_len, 1))
        return dec_out

    def anomaly_detection(self, x_enc):
        # （保持原样）
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc.sub(means)
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc.div(stdev)

        enc_out = self.enc_embedding(x_enc, None)
        for block in self.times_blocks:
            enc_out = self.layer_norm(block(enc_out))
        dec_out = self.projection(enc_out)

        dec_out = dec_out.mul(stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len + self.seq_len, 1))
        dec_out = dec_out.add(means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len + self.seq_len, 1))
        return dec_out

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name in ['long_term_forecast', 'short_term_forecast']:
            dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
            return dec_out[:, -self.pred_len:, :]
        elif self.task_name == 'imputation':
            dec_out = self.imputation(x_enc, x_mark_enc, x_dec, x_mark_dec, mask)
            return dec_out
        elif self.task_name == 'anomaly_detection':
            dec_out = self.anomaly_detection(x_enc)
            return dec_out
        elif self.task_name == 'classification':
            dec_out = self.classification(x_enc, x_mark_enc)
            return dec_out
        else:
            raise ValueError(f"Unknown task: {self.task_name}")
