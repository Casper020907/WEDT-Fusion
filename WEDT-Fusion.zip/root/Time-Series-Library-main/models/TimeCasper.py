import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.Embed import DataEmbedding
from layers.Conv_Blocks import Inception_Block_V2
from torch_geometric.nn import GCNConv
from scipy.stats import kendalltau
import numpy as np
import math
import pywt


# ==============================================================================
# 辅助模块：小波分解 (SWT) - 保持原样
# ==============================================================================
class WaveletEmbedding(nn.Module):
    def __init__(self, d_channel=32, swt=True, requires_grad=False, wv='db4', m=3, kernel_size=None):
        super().__init__()
        self.swt = swt
        self.d_channel = d_channel
        self.m = m
        if kernel_size is None:
            self.wavelet = pywt.Wavelet(wv)
            h0 = torch.tensor(self.wavelet.dec_lo[::-1], dtype=torch.float32)
            h1 = torch.tensor(self.wavelet.dec_hi[::-1], dtype=torch.float32)
            self.h0 = nn.Parameter(torch.tile(h0[None, None, :], [self.d_channel, 1, 1]), requires_grad=requires_grad)
            self.h1 = nn.Parameter(torch.tile(h1[None, None, :], [self.d_channel, 1, 1]), requires_grad=requires_grad)
            self.kernel_size = self.h0.shape[-1]
        else:
            self.kernel_size = kernel_size
            self.h0 = nn.Parameter(torch.Tensor(self.d_channel, 1, self.kernel_size), requires_grad=requires_grad)
            self.h1 = nn.Parameter(torch.Tensor(self.d_channel, 1, self.kernel_size), requires_grad=requires_grad)
            nn.init.xavier_uniform_(self.h0)
            nn.init.xavier_uniform_(self.h1)

    def forward(self, x):
        if self.swt:
            return self.swt_decomposition(x, self.h0, self.h1, self.m, self.kernel_size)
        return x

    def swt_decomposition(self, x, h0, h1, depth, kernel_size):
        approx_coeffs = x
        coeffs = []
        dilation = 1
        for _ in range(depth):
            padding = dilation * (kernel_size - 1)
            padding_r = (kernel_size * dilation) // 2
            pad = (padding - padding_r, padding_r)
            approx_coeffs_pad = F.pad(approx_coeffs, pad, "circular")
            detail_coeff = F.conv1d(approx_coeffs_pad, h1, dilation=dilation, groups=x.shape[1])
            approx_coeffs = F.conv1d(approx_coeffs_pad, h0, dilation=dilation, groups=x.shape[1])
            coeffs.append(detail_coeff)
            dilation *= 2
        coeffs.append(approx_coeffs)
        return torch.stack(list(reversed(coeffs)), -2)


def SWT_for_Period(x, k=3, wavelet='db4', level=None, fixed_period=False):
    B, T, C = x.shape
    device = x.device
    if level is None:
        level = int(math.log2(T)) - 2
        level = max(1, min(level, 5))

    if fixed_period:
        period_list = [2 ** i for i in range(1, k + 1)]
        period_weight = torch.ones(B, k, device=device) / k
        return period_list[:k], period_weight

    x_in = x.permute(0, 2, 1)
    swt_layer = WaveletEmbedding(d_channel=C, swt=True, requires_grad=False, wv=wavelet, m=level).to(device)
    with torch.no_grad():
        coeffs = swt_layer(x_in)

    detail_coeffs = coeffs[:, :, 1:, :]
    energies = torch.sum(detail_coeffs ** 2, dim=-1)
    mean_energies = torch.mean(energies, dim=1)
    global_mean = mean_energies.mean(dim=0)

    topk_vals, topk_indices = torch.topk(global_mean, k=min(k, level))

    period_list = []
    for idx in topk_indices:
        scale_j = level - idx.item()
        period_list.append(2 ** scale_j)

    selected_energies = mean_energies[:, topk_indices]
    period_weight = F.softmax(selected_energies, dim=1)

    if len(period_list) < k:
        period_list += [2] * (k - len(period_list))
        pad = torch.zeros(B, k - period_weight.shape[1], device=device)
        period_weight = torch.cat([period_weight, pad], dim=1)

    return period_list[:k], period_weight


# ==============================================================================
# 辅助模块：注意力与融合 - 保持原样
# ==============================================================================
class CrossAttentionFusion(nn.Module):
    def __init__(self, d_model, n_heads=4, dropout=0.1, q_from='branch1'):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads
        self.q_from = q_from
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(dropout)
        self.scale = self.head_dim ** -0.5

    def forward(self, branch1, branch2):
        B, T, C = branch1.shape
        Q = self.q_proj(branch1 if self.q_from == 'branch1' else branch2)
        K = self.k_proj(branch2 if self.q_from == 'branch1' else branch1)
        V = self.v_proj(branch2 if self.q_from == 'branch1' else branch1)

        Q = Q.view(B, T, self.n_heads, self.head_dim).transpose(1, 2).flatten(0, 1)
        K = K.view(B, T, self.n_heads, self.head_dim).transpose(1, 2).flatten(0, 1)
        V = V.view(B, T, self.n_heads, self.head_dim).transpose(1, 2).flatten(0, 1)

        attn = F.softmax(torch.bmm(Q, K.transpose(-2, -1)) * self.scale, dim=-1)
        out = torch.bmm(self.dropout(attn), V)
        out = out.view(B, self.n_heads, T, self.head_dim).transpose(1, 2).flatten(2, 3)
        out = self.out_proj(out)

        residual = branch1 if self.q_from == 'branch1' else branch2
        return out + residual


class BidirectionalCrossAttentionFusion(nn.Module):
    def __init__(self, d_model, n_heads=4, dropout=0.1):
        super().__init__()
        self.cross_attn_1to2 = CrossAttentionFusion(d_model, n_heads, dropout, q_from='branch1')
        self.cross_attn_2to1 = CrossAttentionFusion(d_model, n_heads, dropout, q_from='branch2')
        self.ffn = nn.Sequential(nn.Linear(d_model, d_model * 2), nn.GELU(), nn.Dropout(dropout),
                                 nn.Linear(d_model * 2, d_model))
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, branch1, branch2):
        out1 = self.cross_attn_1to2(branch1, branch2)
        out2 = self.cross_attn_2to1(branch2, branch1)
        fused = (out1 + out2) / 2.0
        fused = self.norm1(fused)
        fused = fused + self.ffn(fused)
        return self.norm2(fused)


# ==============================================================================
# 核心组件：TimesBlock - 保持原样
# ==============================================================================
class TimesBlock(nn.Module):
    def __init__(self, configs, use_wavelet=True, fixed_period=False):
        super(TimesBlock, self).__init__()
        self.seq_len = configs.seq_len
        self.k = configs.top_k
        self.d_model = configs.d_model
        self.d_ff = getattr(configs, 'd_ff', configs.d_model * 4)
        self.use_wavelet = use_wavelet
        self.fixed_period = fixed_period

        self.conv = nn.Sequential(
            Inception_Block_V2(in_channels=configs.d_model, out_channels=self.d_ff, num_kernels=6),
            nn.GELU(),
            Inception_Block_V2(in_channels=self.d_ff, out_channels=configs.d_model, num_kernels=6)
        )

    def _get_periods_by_fft(self, x):
        B, T, C = x.shape
        device = x.device
        x_perm = x.permute(0, 2, 1)
        fft_res = torch.fft.rfft(x_perm, dim=-1)
        freqs = torch.fft.rfftfreq(T, d=1.0).to(device)
        magnitude = torch.abs(fft_res)
        global_mag = magnitude.mean(dim=1)
        global_mag[:, 0] = -1e-9
        topk_vals, topk_indices = torch.topk(global_mag, k=min(self.k, global_mag.shape[-1]), dim=-1)
        indices = topk_indices[0]
        period_list = []
        for idx in indices:
            freq = freqs[idx].item()
            if freq > 0:
                p = int(round(1.0 / freq))
                p = max(2, min(p, T // 2))
                if p not in period_list:
                    period_list.append(p)
        while len(period_list) < self.k:
            next_p = 2 ** (len(period_list) + 1)
            if next_p <= T // 2 and next_p not in period_list:
                period_list.append(next_p)
            else:
                period_list.append(2)
        period_weight = torch.ones(B, len(period_list), device=device) / len(period_list)
        return period_list[:self.k], period_weight

    def forward(self, x):
        B, T, N = x.size()
        total_len = T
        if self.use_wavelet:
            period_list, period_weight = SWT_for_Period(x, k=self.k, wavelet='db4', fixed_period=self.fixed_period)
        else:
            period_list, period_weight = self._get_periods_by_fft(x)

        actual_k = len(period_list)
        res = []
        for i in range(actual_k):
            period = period_list[i]
            if total_len % period != 0:
                length = ((total_len // period) + 1) * period
                padding = torch.zeros(B, length - total_len, N, device=x.device)
                out = torch.cat([x, padding], dim=1)
            else:
                out = x
                length = total_len

            out = out.reshape(B, length // period, period, N).permute(0, 3, 1, 2).contiguous()
            out = self.conv(out)
            out = out.permute(0, 2, 3, 1).reshape(B, -1, N)
            res.append(out[:, :total_len, :])

        res = torch.stack(res, dim=-1)
        period_weight = F.softmax(period_weight, dim=1).unsqueeze(1).unsqueeze(1).repeat(1, total_len, N, 1)
        return torch.sum(res * period_weight, dim=-1) + x


# ==============================================================================
# 主模型：WEDT-Fusion (已修复 build_graph 维度错误，保留 Kendall Tau)
# ==============================================================================
class Model(nn.Module):
    def __init__(self, configs, ablation_config=None):
        super(Model, self).__init__()
        self.configs = configs
        self.task_name = configs.task_name
        self.seq_len = configs.seq_len
        self.d_model = configs.d_model

        cfg = ablation_config if ablation_config else {}
        self.no_wavelet = cfg.get('no_wavelet', False)
        self.no_adaptive = cfg.get('no_adaptive', False)
        self.no_branch_a = cfg.get('no_branch_a', False)
        self.no_branch_b = cfg.get('no_branch_b', False)
        self.no_smea = cfg.get('no_smea', False)
        self.smea_uni = cfg.get('smea_uni', False)
        self.no_gnn = cfg.get('no_gnn', False)
        self.gnn_static = cfg.get('gnn_static', False)

        self.enc_embedding = DataEmbedding(configs.enc_in, configs.d_model, configs.embed, configs.freq,
                                           configs.dropout)
        self.layer_norm = nn.LayerNorm(configs.d_model)
        self.class_norm = nn.LayerNorm(configs.d_model)

        if not self.no_branch_a:
            self.times_blocks = nn.ModuleList([
                TimesBlock(configs, use_wavelet=not self.no_wavelet, fixed_period=self.no_adaptive)
                for _ in range(configs.e_layers)
            ])
        else:
            self.times_blocks = None

        if not self.no_branch_b:
            try:
                from models.TimeCasper import InceptionTimeEncoderSimple
            except ImportError:
                pass
            self.temp_backbone = InceptionTimeEncoderSimple(d_model=configs.d_model, depth=4, seq_len=configs.seq_len)
        else:
            self.temp_backbone = None

        if not self.no_branch_a and not self.no_branch_b:
            if self.no_smea:
                self.fusion_type = 'add'
                self.fusion_layer = None
            elif self.smea_uni:
                self.fusion_type = 'uni'
                self.fusion_layer = CrossAttentionFusion(configs.d_model, q_from='branch1')
            else:
                self.fusion_type = 'bi'
                self.fusion_layer = BidirectionalCrossAttentionFusion(configs.d_model)
        else:
            self.fusion_type = 'none'
            self.fusion_layer = None

        self.use_gnn = getattr(configs, 'use_gnn', True) and not self.no_gnn
        if self.use_gnn:
            self.gnn1 = GCNConv(configs.d_model, configs.d_model)
            self.gnn2 = GCNConv(configs.d_model, configs.d_model)
            self.gnn_dropout = nn.Dropout(configs.dropout)
            self.gnn_norm = nn.LayerNorm(configs.d_model)
        else:
            self.gnn1 = None

        self.projection = nn.Linear(configs.d_model, configs.num_class)
        self.dropout = nn.Dropout(configs.dropout)

    def build_graph(self, feat):
        """
        【核心修复】
        构建样本间图 (Sample-Level Graph)，严格基于 Batch Size (B)。
        保留 Kendall Tau 算法。

        输入 feat: (B, d_model) - Pooling 后的样本特征。
        注意：为了计算序列间的相关性，我们在 classification 中会传入展平后的特征或 pooling 前的特征，
        但在这里我们统一逻辑：如果传入的是 (B, D)，直接计算；如果是 (B, T, C)，需先展平。
        为了适配原逻辑，这里假设传入的是已经展平或 pooling 后的特征 (B, Dim)。
        """
        # 确保输入是 2D: (B, Dim)
        if feat.dim() == 3:
            B, T, C = feat.shape
            feat = feat.view(B, -1)  # 展平成 (B, T*C)

        B, D = feat.shape
        device = feat.device

        # 获取配置的 k，并确保不超过 B-1
        k = getattr(self.configs, 'gnn_k', 5)
        k = min(k, B - 1)

        # 处理极端情况
        if B == 1:
            return torch.tensor([[0], [0]], device=device, dtype=torch.long)
        if k <= 0:
            return torch.tensor([[], []], device=device, dtype=torch.long)

        if self.gnn_static:
            row = torch.arange(B, device=device).repeat_interleave(B)
            col = torch.arange(B, device=device).repeat(B)
            mask = row != col
            return torch.stack([row[mask], col[mask]], dim=0)

        # --- 动态 Kendall Tau 逻辑 (严格基于 B) ---

        # 1. 转为 numpy 用于 scipy 计算
        # feat 形状: (B, D)
        feat_np = feat.detach().cpu().numpy()

        # 2. 初始化相关性矩阵 (B, B)
        tau_mat = np.zeros((B, B), dtype=np.float32)

        # 3. 双重循环计算 Kendall Tau
        # 只计算上三角，然后对称复制
        for i in range(B):
            for j in range(i + 1, B):
                try:
                    # 计算样本 i 和 样本 j 之间的相关性
                    tau, _ = kendalltau(feat_np[i], feat_np[j])
                    # 取最大值 0 (忽略负相关，或者根据需求保留)
                    val = max(tau, 0.0)
                    tau_mat[i, j] = val
                    tau_mat[j, i] = val
                except Exception:
                    # 防止计算失败 (如常数序列)
                    pass

        # 4. 转回 Tensor
        tau_tensor = torch.tensor(tau_mat, device=device)

        # 5. 选取 Top-K
        # 关键修复：这里的 dim=1 表示对每一行 (每个样本) 选 K 个邻居
        # 结果形状: (B, k)
        _, topk_indices = torch.topk(tau_tensor, k=k, dim=1)

        # 6. 构建 row 索引
        # 形状: (B, k) -> [0,0,..,0, 1,1,..,1, ...]
        row_indices = torch.arange(B, device=device).unsqueeze(1).repeat(1, k)

        # 7. 堆叠并展平
        # row_indices.flatten() 长度 = B * k
        # topk_indices.flatten() 长度 = B * k
        # 此时两者长度严格相等，彻底解决报错
        edge_index = torch.stack([row_indices.flatten(), topk_indices.flatten()], dim=0)

        return edge_index

    def classification(self, x_enc, x_mark_enc):
        enc_out = self.enc_embedding(x_enc, None)
        feats = []

        # Branch A
        if self.times_blocks:
            out = enc_out
            for blk in self.times_blocks:
                out = self.layer_norm(blk(out))
            feats.append(out)

        # Branch B
        if self.temp_backbone:
            feats.append(self.temp_backbone(enc_out))

        # Fusion
        if len(feats) == 0:
            raise ValueError("No branches")
        if len(feats) == 1:
            fused = feats[0]
        else:
            if self.fusion_type == 'bi':
                fused = self.fusion_layer(feats[1], feats[0])
            elif self.fusion_type == 'uni':
                fused = self.fusion_layer(feats[1], feats[0])
            else:  # add
                fused = (feats[0] + feats[1]) / 2.0
                fused = self.layer_norm(fused)

        # Pooling: (B, T, d_model) -> (B, d_model)
        if x_mark_enc is None:
            feat = fused.mean(dim=1)
        else:
            feat = (fused * x_mark_enc.unsqueeze(-1)).sum(dim=1) / (x_mark_enc.sum(dim=1, keepdim=True) + 1e-8)

        feat = self.class_norm(feat)

        # GNN
        if self.use_gnn and self.gnn1:
            # 【修复点】
            # 原代码传入 x_enc (B, T, C) 导致内部展平逻辑可能混淆 C 和 B。
            # 这里我们传入原始的 x_enc (未 pooling) 给 build_graph，
            # 让 build_graph 内部将其展平为 (B, T*C) 来计算样本间的序列相关性。
            # 这样既保留了 Kendall Tau 对原始序列形态的敏感性，又保证了维度基于 B。
            edge_index = self.build_graph(x_enc)

            # GNN 的节点特征依然使用 pooling 后的 feat (B, d_model)
            gnn_out = F.relu(self.gnn1(feat, edge_index))
            gnn_out = self.gnn_dropout(gnn_out)
            gnn_out = self.gnn2(gnn_out, edge_index)
            feat = self.gnn_norm(gnn_out + feat)

        return self.projection(self.dropout(feat))

    def forward(self, x_enc, x_mark_enc, x_dec, x_mark_dec, mask=None):
        if self.task_name == 'classification':
            return self.classification(x_enc, x_mark_enc)
        return None


# ==============================================================================
# 辅助类：InceptionTime Encoder
# ==============================================================================
class InceptionTimeEncoderSimple(nn.Module):
    def __init__(self, d_model, depth=4, seq_len=64):
        super().__init__()
        if seq_len > 32:
            kernels = [7, 11, 21]
        else:
            kernels = [3, 5, 7]

        layers = []
        for _ in range(depth):
            layers.append(InceptionBlockSimple(d_model, d_model, kernels))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        x = x.transpose(1, 2)
        x = self.net(x)
        return x.transpose(1, 2)


class InceptionBlockSimple(nn.Module):
    def __init__(self, in_ch, out_ch, kernels):
        super().__init__()
        bottleneck_out = 32 if in_ch > 32 else in_ch
        self.bottleneck = nn.Conv1d(in_ch, bottleneck_out, 1) if in_ch > 32 else nn.Identity()

        num_kernels = len(kernels)
        base_ch = out_ch // num_kernels
        remainder = out_ch % num_kernels

        conv_layers = []
        for i, k in enumerate(kernels):
            ch_out = base_ch + (remainder if i == num_kernels - 1 else 0)
            conv_layers.append(nn.Conv1d(bottleneck_out, ch_out, k, padding=k // 2))

        self.convs = nn.ModuleList(conv_layers)
        self.bn = nn.BatchNorm1d(out_ch)
        self.res = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else nn.Identity()

    def forward(self, x):
        res = self.res(x)
        x = self.bottleneck(x)
        x = torch.cat([c(x) for c in self.convs], dim=1)
        return F.relu(self.bn(x) + res)